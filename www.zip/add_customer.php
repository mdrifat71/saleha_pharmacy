<?php
session_start();
include_once 'class/Session.php';
if(Session::check("login", "true")){
    $user_name= Session::get("username");
}else{
    header("location:login.php");
}

include 'class/Customer.php';
include_once 'class/Utility.php';
$customer = new Customer();
date_default_timezone_set('Asia/Dhaka');

if(isset($_POST['add'])){
    $customer_name = $_POST['customer_name'];
    $customer_address = $_POST['customer_address'];
    $customer_mobile = $_POST['customer_mobile'];
    $customer_due = $_POST['customer_due'];
    $customer_join_date = date('Y:m:d h:i:s');

    if($customer->setter($customer_name, $customer_address, $customer_mobile, $customer_due,$customer_join_date)){
        if ($customer->insert()){
            $submition = true;
        }else{
            $submition = false;
        }
    }else{
        $submition = false;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="icons/css/all.css">
    <link rel="stylesheet" href="css/style.css?<?php echo date('Y-m-d_H:i:s'); ?>">
</head>
<body class="bg-light">
    
    <!--header start-->
    <section id = "header" style="position:sticky; z-index:1000000;;top:0">
        <div class=" btn-block bg-warning text-center" style ="letter-spacing:3px">
            SALEHA PHARMACY
        </div>
        <div class="container">
           
                <ul>
                    <li class="">
                        <a href="index.php" >
                            <i class="fa fa-address-book  menu-icon"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="customer_list.php">
                            <i class="fa fa-users  menu-icon"></i>
                            <span>Customer List</span>
                        </a>
                    </li>
                    <li class="a-menu">
                        <a href="">
                            <i class="fa fa-plus menu-icon"> <i class="fa fa-users"></i></i>
                            <span>Add customer</span>
                        </a>
                    </li>
                    <li>
                        <a href="add_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-briefcase  menu-icon"></i></i>
                            <span>Add due</span>
                        </a>
                    </li>
                    <li>
                        <a href="pay_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-credit-card  menu-icon"></i></i>
                            <span>Pay due</span>
                        </a>
                    </li>
                    <li class="logout">
                        <a href="logout.php?logout">
                            <i class="fa fa-sign-out  menu-icon"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                    <li class="back">
                        <button class="btn " onclick="history.go(-1)"><i class=" fa fa-arrow-left"></i></button>
                    </li>
                    
                </ul>
            
        </div>
    </section>

    <!--header end-->

    <!--add customrer-->

    <section id="add-customer">
        <div class="container">
           <div class="row">
               
               <div class="col-lg-8 mb-4">
                <div class="card mt-5 bg-dark text-white">
                    <div class="card-header">
                        <h4>CUSTOMER DETAILS</h4>
                    </div>
                    <div class="card-body customer-form">
                        <form action="" method = "post">
                            <div class="form-group">
                                <label for="customer_name">Name</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fa fa-user"></i></span>
                                    </div>
                                    <input type="text" class="form-control" id="customer_name" placeholder="Name" name ="customer_name">
                                </div>
                                
                              </div>
                            <div class="form-row">
                              <div class="form-group col-md-6">
                                <label for="customer_address">Adress</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fa fa-map-marker"></i></span>
                                    </div>
                                    <input type="text" class="form-control" id="customer_address" placeholder="Adress" name = "customer_address">
                                </div>
                                
                              </div>
                              <div class="form-group col-md-6">
                                <label >Contact</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fa fa-phone"></i></span>
                                    </div>
                                    <input type="number" class="form-control"  id = "customer_mobile" placeholder="Contact" name = "customer_mobile">
                                </div>
                              </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                  <label for="">Previous Due</label>
                                  <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">৳</i></span>
                                    </div>
                                    <input type="number" class="form-control" id="customer_due" placeholder="Due" name = "customer_due"> 
                                  </div>                                  
                                </div>
                                <div class="form-group col-md-6">
                                  <label for="">Type</label>
                                  <select name="" class="form-control" id ="select">
                                    <option value="2" >Customer</option>
                                    <option value="1" >Doctor</option>
                                  </select>
                                </div>
                                
                              </div>
                            
                            <button type="submit" class="btn btn-info" name ="add" id = "customer_add_btn">ADD</button>
                          </form>
                    </div>
                </div>
               
               </div>
               <div class="col-lg-4 mb-4">
                   <div class="card customer_adding_history mt-5 d-hid">
                       <div class="card-body" id = "adding_notification_body">

                       </div>
                   </div>
               </div>
           </div>
        </div>
    </section>

    <div class="btn-block  py-2 footer bg-dark text-center text-light" style ="text-transform:uppercase; letter-spacing:3px; font-size:12px;position:absolute; bottom:0;">&copy MD Rifat Sarker</div>
   <script src = "js/customer.js?<?php echo date('Y-m-d_H:i:s'); ?>"></script>
  
    <script src="js/all.js?v=<?php echo date('d-m-i') ?>"></script>
</body>
</html>