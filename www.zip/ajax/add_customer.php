<?php

include '../class/Customer.php';
include '../class/Add_due.php';
$customer = new Customer;
$add_due = new Add_due;
date_default_timezone_set('Asia/Dhaka');
if(isset($_POST['customer_name'])){
    
    $customer_id = md5(uniqid());
    $customer_name = $_POST['customer_name'];
    $customer_address = $_POST['customer_address'];
    $customer_mobile = $_POST['customer_mobile'];
    $customer_due =  $_POST['customer_due'] ;
    $customer_join_date = date('Y:m:d h:i:s');
    $customer_type = $_POST['customer_type'];

    $due_id = md5(uniqid());
    if($customer->setter($customer_id,$customer_name, $customer_address, $customer_mobile, $customer_due,$customer_join_date,$customer_type)){
        
        
        
        if ($customer->insert()){
            if(!empty($customer_due)){
                if($add_due->setter($due_id,$customer_due,$customer_id, $customer_join_date)){
                    if($add_due->insert()){
                        $submition = $customer_id;
                    }else{
                        $submition = 0;
                    }
                }else{
                    $submition = 5;
                }
            }else{
                $submition = $customer_id;
            }
        }else{
            $submition = 0;
        }
        
    }

    echo $submition;
    
}