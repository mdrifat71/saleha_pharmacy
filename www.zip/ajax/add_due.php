<?php

include '../class/Add_due.php';
include '../class/Customer.php';
include '../class/Sell.php';
$sell = new Sell;
$customer = new Customer;
$add_due = new Add_due;
date_default_timezone_set('Asia/Dhaka');

if(isset($_POST['customer_id']) && $_POST['action'] == 'add'){
    $due_id = md5(uniqid());
    $customer_id = $_POST['customer_id'];
    $due = $_POST['customer_due'];
    $due_date =  date('Y:m:d h:i:s');
    
    if($add_due->setter($due_id,$due,$customer_id, $due_date)){
        
        
         if($add_due->insert()){
           
            $customer->updateById($customer_id, $due);
            $sell_id = md5(uniqid());
            if($sell->setter($sell_id, $due,$due_date)){
                if($sell->insert()){
                    echo $due_id;
                }else{
                    echo 0;
                }
            }else{
                echo 0;
            }
         }else{
             echo "0";
         }
         
    }
    else{
        echo "2";
    }
    
}

if(isset($_POST['action']) && $_POST['action'] == 'delete'){
    $id = $_POST['due_id'];
    $due = $_POST['due'];
    $customer_id = $_POST['customer_id'];
    
    if($add_due->deleteById($id)){
          $customer->updateById($customer_id, -$due);
          echo "1";
      }else{
          echo "0";
      }
      
}


if(isset($_POST['action']) && $_POST['action'] == "clear_due"){
    $id = $_POST['due_id'];
    if($add_due->deleteById($id)){
        echo 1;
    }else{
        echo 0;
    }
}

if(isset($_POST['action']) && $_POST['action'] == "clear_all_due"){
    $id = $_POST['customer_id'];
    if($add_due->deleteByCustomerId($id)){
        echo 1;
    }else{
        echo 0;
    }
}