<?php
include_once '../class/Company_due.php';

$company_due = new Company_due;

if(isset($_POST['action']) && $_POST['action'] == 'clear_due'){
    $company_due_id = $_POST['due_id'];
    if($company_due->deleteById($company_due_id)){
        echo 1;
    }else{
        echo 0;
    }
}

if(isset($_POST['action']) && $_POST['action'] == 'clear_all_due'){
    $company_id = $_POST['company_id'];
    if($company_due->deleteByCompanyId($company_id)){
        echo 1;
    }else{
        echo 0;
    }
}