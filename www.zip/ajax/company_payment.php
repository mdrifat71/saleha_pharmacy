<?php
include_once '../class/Company_payment.php';

$company_payment = new Company_payment;

if(isset($_POST['action']) && $_POST['action'] == 'clear_payment'){
    $company_payment_id = $_POST['payment_id'];
    if($company_payment->deleteById($company_payment_id)){
        echo 1;
    }else{
        echo 0;
    }
}

if(isset($_POST['action']) && $_POST['action'] == 'clear_all_payment'){
    $company_id = $_POST['company_id'];
    if($company_payment->deleteByCompanyId($company_id)){
        echo 1;
    }else{
        echo 0;
    }
}