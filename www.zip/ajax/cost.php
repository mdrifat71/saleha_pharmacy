<?php

include_once '../class/Cost.php';
$cost = new Cost;

if(isset($_POST['action']) && $_POST['action'] == "clear_cost"){
    $id = $_POST['cost_id'];
    if($cost->deleteById($id)){
        echo 1;
    }else{
        echo 0;
    }
}