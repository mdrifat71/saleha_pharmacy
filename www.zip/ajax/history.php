<?php

include '../class/Add_due.php';
include '../class/Pay_due.php';
include '../class/Sell.php';
include '../class/Company_due.php';
include '../class/Company_payment.php';
include '../class/Cost.php';

//object of each class

$customer_due = new Add_due();
$customer_payment = new Pay_due();
$company_payment = new Company_payment();
$company_due = new Company_due();
$cost = new Cost;
$sell = new Sell;
//function for eaach action//
 function customer_due_action ($date, $month , $year, $customer_due) {
    $result = $customer_due->history_by_date($date,$month, $year);
    if(empty($result[0])) {
        echo 0;
        return 0;
    }
    ob_start();
    ?>
    <div class="btn-group mb-2">
    <div class="total btn btn-lg btn-dark rounded-0">TOTAL </div>  <span class=" rounded-0 btn font-weight-bold"> <?php echo $result[1]?>৳</span>
    </div>
    <hr>
<?php
    foreach($result[0] as $row){
?>
        <div class="alert alert-danger d-flex text-muted due_history_item">
            <p class="m-0">Due ৳<?php echo $row['due']?>, <b><a href="customer_profile.php?id=<?php echo $row['customer_id'] ?>"><?php echo $row['customer_name'] ?></a></b></p>
            <span class="ml-auto"><?php echo $row['date']?></span>
            <button class="btn btn-sm btn-danger del_btn ml-2" id = "<?php echo $row['due_id'] ?>"><i class="fa fa-times "></i></button>
        </div>

<?php
    }

    $output = ob_get_clean();
    echo $output;
}


//payment payment action
function customer_payment_action($date, $month , $year, $customer_payment){
    $result = $customer_payment->history_by_date($date,$month, $year);
    
    
    if(empty($result[0])) {
        echo 0;
        return 0;
    }
    ob_start();
?>
    <div class="btn-group mb-2">
    <div class="total btn btn-lg btn-dark rounded-0">TOTAL </div>  <span class=" rounded-0 btn font-weight-bold"> <?php echo $result[1]?>৳</span>
    </div>
    <hr>
<?php
    foreach($result[0] as $row){
?>
        <div class="alert alert-success d-flex text-muted due_history_item">
            <p class="m-0">Paid ৳<?php echo $row['payment_ammount']?>, <b><a href="customer_profile.php?id=<?php echo $row['customer_id'] ?>"><?php echo $row['customer_name'] ?></a></b></p>
            <span class="ml-auto "><?php echo $row['date']?></span>
            <button class="btn btn-sm btn-danger del_btn ml-2" id = "<?php echo $row['payment_id'] ?>"><i class="fa fa-times"></i></button>
        </div>

<?php
    }

    $output = ob_get_clean();
    echo $output;
}


//company payment action
function company_payment_action($date, $month , $year, $obj){
    $result = $obj->history_by_date($date,$month, $year);
    if(empty($result[0])) {
        echo 0;
        return 0;
    }
    ob_start();
?>
    <div class="btn-group mb-2">
    <div class="total btn btn-lg btn-dark rounded-0">TOTAL </div>  <span class=" rounded-0 btn font-weight-bold"> <?php echo $result[1]?>৳</span>
    </div>
    <hr>
<?php
    foreach($result[0] as $row){
?>
        <div class="alert alert-success d-flex text-muted due_history_item">
            <p class="m-0">Pay ৳<?php echo $row['company_payment']?>,To <b><a href="company_profile.php?id=<?php echo $row['company_id'] ?>"><?php echo $row['company_name'] ?></a></b></p>
            <span class="ml-auto "><?php echo $row['date']?></span>
            <button class=" btn btn-sm btn-danger del_btn ml-2" id = "<?php echo $row['company_payment_id'] ?>"><i class="fa fa-times"></i></button>
        </div>

<?php
    }

    $output = ob_get_clean();
    echo $output;
}

//company payment action
function company_due_action($date, $month , $year, $obj){
    $result = $obj->history_by_date($date,$month, $year);
    if(empty($result[0])) {
        echo 0;
        return 0;
    }
    ob_start();
?>
    <div class="btn-group mb-2">
    <div class="total btn btn-lg btn-dark rounded-0">TOTAL </div>  <span class=" rounded-0 btn font-weight-bold"> <?php echo $result[1]?>৳</span>
    </div>
    <hr>
<?php
    foreach($result[0] as $row){
?>
        <div class="alert alert-danger d-flex text-muted due_history_item">
            <p class="m-0">Due ৳<?php echo $row['company_due']?>, <b><a href="company_profile.php?id=<?php echo $row['company_id'] ?>"><?php echo $row['company_name'] ?></a></b></p>
            <span class="ml-auto "><?php echo $row['date']?></span>
            <button class="btn btn-sm btn-danger del_btn ml-2" id = "<?php echo $row['company_payment_id'] ?>"><i class="fa fa-times"></i></button>
        </div>

<?php
    }

    $output = ob_get_clean();
    echo $output;
}

//cost action
function cost_action($date, $month , $year, $obj){
    $result = $obj->history_by_date($date,$month, $year);
    if(empty($result[0])) {
        echo 0;
        return 0;
    }
    ob_start();
 ?>
    <div class="btn-group mb-2">
        <div class="total btn btn-lg btn-dark rounded-0">TOTAL </div>  <span class=" rounded-0 btn font-weight-bold"> <?php echo $result[1]?>৳</span>
    </div>
    <hr>
<?php
    foreach($result[0] as $row){
?>
        <div class="alert alert-danger d-flex text-muted due_history_item">
            <p class="m-0">Spend ৳<b><?php echo $row['cost_ammount']?></b> [ <b><?php echo $row['cost_description'] ?>]</b></p>
            <span class="ml-auto "><?php echo $row['date']?></span>
            <button class="btn btn-sm btn-danger del_btn ml-2" id = "<?php echo $row['cost_id'] ?>"><i class="fa fa-times"></i></button>
        </div>

<?php
    }

    $output = ob_get_clean();
    echo $output;
}


//sell action
function sell_action($date, $month , $year, $obj){
    $result = $obj->history_by_date($date,$month, $year);
    if(empty($result)) {
        echo 0;
        return 0;
    }
    ob_start();
?>
    <div class="btn-group mb-2">
    <div class="total btn btn-lg btn-dark rounded-0">TOTAL </div>  <span class=" rounded-0 btn font-weight-bold"> <?php echo $result[1]?>৳</span>
    </div>
    <hr>
<?php
    foreach($result[0] as $row){
?>
        <div class="alert alert-success d-flex text-muted due_history_item">
            <p class="m-0">Sell ৳<?php echo $row['sell_ammount']?> </b></p>
            <span class="ml-auto "><?php echo $row['date']?></span>
            <button class="btn btn-sm btn-danger del_btn ml-2" id = "<?php echo $row['sell_id'] ?>"><i class="fa fa-times"></i></button>
        </div>

<?php
    }

    $output = ob_get_clean();
    echo $output;
}

//checkking ajax request
if(isset($_POST['selected'])){
    $selected = $_POST['selected'];
    $date = $_POST['date'];
    $month = $_POST['month'];
    $year = $_POST['year'];

    switch($selected){
        case 1:
            customer_payment_action($date, $month, $year,$customer_payment);
            break;
        
        case 2:
            customer_due_action($date, $month, $year, $customer_due);
            break;
        case 3:
            company_payment_action($date, $month, $year, $company_payment);
            break;
        case 4:
            company_due_action($date, $month, $year, $company_due);
             break;
        case 5:
            cost_action($date, $month, $year, $cost);
            break;
        case 6:
            sell_action($date, $month, $year, $sell);
            break;
    }
}

