<?php
include '../class/Pay_due.php';
include '../class/Customer.php';

$customer = new Customer;
$pay_due = new Pay_due;
date_default_timezone_set('Asia/Dhaka');
if(isset($_POST['action']) && $_POST['action'] == "add_payment"){
    $customer_id = $_POST['customer_id'];
    $customer_payment = $_POST['customer_payment'];
    $payment_id = md5(uniqid());
    $payment_date = date('Y:m:d h:i:s');
    if($pay_due->setter($payment_id, $customer_payment, $customer_id,$payment_date)){
        if($pay_due->insert()){
            echo $payment_id;
            $customer->updateById($customer_id, -1*$customer_payment);//update due
        }else{
            echo 0;
        }
        
    }else{
        echo 0;
    }
    
    
}

if(isset($_POST['action']) && $_POST['action'] == "check_due"){
    $id = $_POST['customer_id'];
    $r = $customer->customer_due_by_id($id);
    echo $r['customer_due'];

}

if(isset($_POST['action']) && $_POST['action'] == "delete_payment"){
    $id = $_POST['payment_id'];
    $customer_id = $_POST['customer_id'];
    $customer_payment =$_POST['customer_payment'];
  //  echo $id;
    
    if($pay_due->deleteById($id)){
        
        $customer->updateById($customer_id, $customer_payment);
    }
}

if(isset($_POST['action']) && $_POST['action'] == "clear_payment"){
    $id = $_POST['payment_id'];
    if($pay_due->deleteById($id)){
        echo 1;
    }else{
        echo 0;
    }
}

if(isset($_POST['action']) && $_POST['action'] == "clear_all_payment"){
    $id = $_POST['customer_id'];
    if($pay_due->deleteByCustomerId($id)){
        echo 1;
    }else{
        echo 0;
    }
}