<?php

include_once '../class/Sell.php';
$sell = new Sell;

if(isset($_POST['action']) && $_POST['action'] == "clear_sell"){
    $id = $_POST['sell_id'];
    if($sell->deleteById($id)){
        echo 1;
    }else{
        echo 0;
    }
}