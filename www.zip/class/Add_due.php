<?php 
include_once 'Database.php';
include_once 'Utility.php';
class Add_due extends Database{
    private $table = 'due_table';
    private $due_id;
    private $customer_id;
    private $due;
    private $due_date;

    public function __construct(){
        parent::__construct();
    }

    public function setter($due_id, $due, $customer_id,$due_date){
        if($this->validate($due_id, $due, $customer_id,$due_date)){
            $this->due_id = $due_id;
            $this->due = $due;
            $this->customer_id = $customer_id;
            $this->due_date = $due_date;
            return true;
        }
        else{
            return false;
        }
    }

    public function validate($due_id,$due, $customer_id, $due_date){
        if (empty($due_id) or empty($due) or empty($customer_id) or empty($due_date)){
            return false;
        }
        return true;
    }

    public function insert(){
        
        $sql = "insert into `$this->table` (`due_id`, `customer_id`, `due`, `due_date`) values (:due_id, :customer_id, :due, :due_date)";
        
        $stmt= Database::$connection->prepare($sql);
        $stmt->bindParam(":due_id", $this->due_id);
        $stmt->bindParam(":customer_id", $this->customer_id);
        $stmt->bindParam(":due", $this->due);
        $stmt->bindParam(":due_date", $this->due_date);
        return $stmt->execute(); 
    }

    public function DeleteById($id){
        $sql = "Delete from `$this->table` where `due_id` = ?";
        $stmt = Database::$connection->prepare($sql);
        return $stmt->execute(array($id));
    }

    public function due_history(){
        $sql = "Select $this->table.*, customer_table.customer_name from $this->table inner join customer_table on $this->table.customer_id = customer_table.customer_id order by $this->table.due_date desc limit 100";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function selectById($id){
        $sql = "select * from $this->table where customer_id = ? order by due_date desc";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute(array($id));
       return $stmt->fetchAll();

    }

    public function count(){
        $sql = "select * from $this->table";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        return count($stmt->fetch(PDO::FETCH_ASSOC));
    }

    public function deleteByCustomerId($id){
        $sql = "Delete from `$this->table` where `$this->table`.`customer_id` = ?";
        $stmt = Database::$connection->prepare($sql);
        return $stmt->execute(array($id));
    }

    public function deleteByCustomer($id){
        $sql = "Delete from `$this->table` where `customer_id` = ?";
        $stmt = Database::$connection->prepare($sql);
        return $stmt->execute(array($id));
    }

    public function due_today(){
        $sql ="SELECT `due`, `due_date` from $this->table";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        $r = $stmt->fetchAll();
        return Utility::due_today($r);
    }

    public function due_this_month(){
        $sql ="SELECT `due`, `due_date` from $this->table";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        $r = $stmt->fetchAll();
        return Utility::due_this_month($r);
    }

    public function history_by_date($date, $month, $year ){
        $sql = "Select $this->table.*, customer_table.customer_name from $this->table inner join customer_table on $this->table.customer_id = customer_table.customer_id order by $this->table.due_date desc";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        $result = Utility::match_by_date($stmt->fetchAll(),$date, $month, $year, 'due_date','due');
        return $result;
    }
}