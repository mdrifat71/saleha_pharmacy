<?php

include_once 'Admin_db.php';

class Admin extends Admin_db{
    private $table = "admin_table";
    public function __construct(){
        parent::__construct();
        $sql = 'CREATE TABLE IF NOT EXISTS "admin_table" (
            "admin_id"	INTEGER,
            "admin_username"	TEXT,
            "admin_password"	TEXT,
            "admin_full_name"	TEXT,
            "security_question"	TEXT,
            "security_question_answer"	TEXT,
            PRIMARY KEY("admin_id" AUTOINCREMENT)
        )';
        $stmt = Admin_db::$connection->prepare($sql);
        $stmt->execute();
    }

    public function select(){
        $sql = "select * from $this->table";
        $stmt = Admin_db::$connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function insert($admin_username, $admin_password, $admin_full_name, $security_question, $security_question_answer){
        $sql = "insert into $this->table (`admin_username`, `admin_password`, `admin_full_name`, `security_question`, `security_question_answer`) values (:admin_username, :admin_password, :admin_full_name, :security_question, :security_question_answer)";
        $stmt = Admin_db::$connection->prepare($sql);
        $stmt->bindParam(":admin_username", $admin_username);
        $stmt->bindParam(":admin_password", $admin_password);
        $stmt->bindParam(":admin_full_name", $admin_full_name);
        $stmt->bindParam(":security_question",$security_question);
        $stmt->bindParam(":security_question_answer", $security_question_answer);
        return $stmt->execute();
    }

    public function match($admin_username, $admin_password){
        
        $admin_password = str_replace(array(':', '-', '/', '*', "'", '"'), '', $admin_password);
        $admin_username = str_replace(array(':', '-', '/', '*', "'", '"'), '', $admin_username);
        $sql = "select * from $this->table where `admin_username` = '$admin_username' and `admin_password` = '$admin_password'";
        $stmt = Admin_db::$connection->prepare($sql);
     
        $stmt->execute();
        return count($stmt->fetchAll()) ;
        if(count($stmt->fetchAll()) >= 1){
            return true;
        }
        return false;
    }
}