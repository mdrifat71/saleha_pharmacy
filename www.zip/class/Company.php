<?php
include_once "Database.php";
include_once "Utility.php";

class Company extends Database{
    public function __construct(){
        parent::__construct();
    }
    private $table = "company_table";
    private $company_id;
    private $company_name;
    private $representative_name;
    private $representative_mobile;
    private $company_due;

    public function setter($company_id, $company_name, $company_due, $representative_name, $representative_mobile){
        $this->company_id = $company_id;
        $this->company_name = $company_name;
        $this->company_due = $company_due;
        $this->representative_name = $representative_name;
        $this->representative_mobile = $representative_mobile;
        return true;
    }

    public function insert(){
        $sql = "Insert into $this->table (`company_id`, `company_name`, `company_due`, `representative_name`, `representative_mobile`) values (:company_id, :company_name, :company_due, :representative_name, :representative_mobile)";  
        $stmt = Database::$connection->prepare($sql);
        $stmt->bindParam(":company_id", $this->company_id);
        $stmt->bindParam(":company_name", $this->company_name);
        $stmt->bindParam(":company_due", $this->company_due);
        $stmt->bindParam(":representative_name", $this->representative_name);
        $stmt->bindParam(":representative_mobile", $this->representative_mobile);
        return $stmt->execute();
    }

    public function count(){
        $sql = "select * from $this->table";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        return count($stmt->fetchAll());
    }

    public function total_due(){
        $sql = "select SUM(company_due) as total_due from $this->table";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        $r = $stmt->fetch(PDO::FETCH_ASSOC);
        return $r['total_due'];
    

    }

    public function all_company(){
        $sql = "select `company_name` from $this->table ";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function selectAll(){
        $sql = "select * from `$this->table` order by LOWER(`company_name`)";
        $stmt = Database::$connection->prepare($sql);
       
       try{
           $stmt->execute();
           return $stmt;
       }catch(PDOException $e)
       {
            return "Statement failed: " . $e->getMessage();
            
       }
    }

    public function isCompanyExist($company_name){
        $company_name = strtolower($company_name);
        $sql = "select `company_name` from $this->table where lower(`company_name`) = :company_name";
        $stmt = Database::$connection->prepare($sql);
        $stmt->bindParam(":company_name", $company_name);
        $stmt->execute();
        if(count($stmt->fetchAll()) > 0){
            return true;
        }else{
            return false;
        }
    }

    public function deleteById($id){
        $sql = "Delete from `$this->table` where `company_id` = ?";
        $stmt = Database::$connection->prepare($sql);
        return $stmt->execute(array($id));
    }

    public function selectById($id){
        $sql = "select * from $this->table where company_id = ?";
        $stmt= Database::$connection->prepare($sql);
        $stmt->execute(array($id));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function update($company_name, $representative_name, $representative_mobile,$company_id){
        $sql = "Update $this->table 
                set `company_name` = :company_name,
                    `representative_name` = :representative_name,
                    `representative_mobile` = :representative_mobile      
                where `company_id` = :company_id
        ";

        $stmt = Database::$connection->prepare($sql);
        $stmt->bindParam(":company_name", $company_name);
        $stmt->bindParam(":representative_name", $representative_name);
        $stmt->bindParam(":representative_mobile", $representative_mobile);
        $stmt->bindParam(":company_id", $company_id);
        return $stmt->execute();
      
    }

    public function updateById($company_id,$due){
        if(is_numeric($due)){
            $sql = "UPDATE `$this->table` SET `company_due` = `$this->table`.`company_due` + $due WHERE `$this->table`.`company_id` = '$company_id' ";
            $stmt = Database::$connection->prepare($sql);
            return $stmt->execute();
        }else{
            return false;
        }
     }
}