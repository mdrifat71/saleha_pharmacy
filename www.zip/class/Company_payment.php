<?php

include_once "Database.php";
include_once "Utility.php";

class Company_payment extends Database{
    public function __construct(){
        parent::__construct();
    }
    private $table = "company_payment_table";
    private $company_payment_id ;
    private $company_id;
    private $company_payment;
    private $company_payment_date;

    public function setter($company_payment_id, $company_id, $company_payment, $company_payment_date){
        $this->company_payment_id = $company_payment_id;
        $this->company_id = $company_id;
        $this->company_payment = $company_payment;
        $this->company_payment_date  = $company_payment_date;
        return true;
    }

    public function insert(){
        $sql = "insert into $this->table(`company_payment_id`, `company_id`, `company_payment`, `company_payment_date`) values (:company_payment_id, :company_id, :company_payment, :company_payment_date)";

        $stmt = Database::$connection->prepare($sql);
        $stmt->bindParam(":company_payment_id", $this->company_payment_id);
        $stmt->bindParam(":company_id", $this->company_id);
        $stmt->bindParam(":company_payment", $this->company_payment);
        $stmt->bindParam(":company_payment_date", $this->company_payment_date);
        return $stmt->execute();
    }

    public function deleteByCompanyId($id){
        $sql = "Delete from `$this->table` where `$this->table`.`company_id` = ?";
        $stmt = Database::$connection->prepare($sql);
        return $stmt->execute(array($id));
    }

    public function payment_history(){
        $sql = "Select $this->table.*, company_table.company_name from $this->table inner join company_table on $this->table.company_id = company_table.company_id order by $this->table.company_payment_date desc limit 100";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function selectById($id){
        $sql = "select * from $this->table where company_id = ? order by company_payment_date desc";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute(array($id));
       return $stmt->fetchAll();

    }

    public function DeleteById($id){
        $sql = "Delete from `$this->table` where `company_payment_id` = ?";
        $stmt = Database::$connection->prepare($sql);
        return $stmt->execute(array($id));
    }

    public function history_by_date($date, $month, $year){
        $sql = "Select $this->table.*, company_table.company_name from $this->table inner join company_table on $this->table.company_id = company_table.company_id order by $this->table.company_payment_date desc";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        $result = Utility::match_by_date($stmt->fetchAll(),$date, $month, $year, 'company_payment_date','company_payment');
        return $result;
    }

}
