<?php

include_once "Database.php";
include_once "Utility.php";

class Cost extends Database{
    public function __construct(){
        parent::__construct();
    }
    private $table = "cost_table";
    private $cost_id;
    private $cost_ammount;
    private $cost_description;
    private $cost_date;

    public function setter($cost_id,$cost_ammount, $cost_description, $cost_date){
        $this->cost_id = $cost_id;
        $this->cost_ammount = $cost_ammount;
        $this->cost_description = $cost_description;
        $this->cost_date = $cost_date;
        return true;
    }

    public function insert(){
        $sql = "insert into $this->table (`cost_id`, `cost_ammount`, `cost_description`, `cost_date`) values (:cost_id, :cost_ammount, :cost_description, :cost_date)";
        $stmt = Database::$connection->prepare($sql);
        $stmt->bindParam(":cost_id", $this->cost_id);
        $stmt->bindParam(":cost_ammount", $this->cost_ammount);
        $stmt->bindParam(":cost_description", $this->cost_description);
        $stmt->bindParam(":cost_date", $this->cost_date);
        return $stmt->execute();
    }

    public function cost_today(){
        $sql = "select * from $this->table";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        $r = $stmt->fetchAll();
        return Utility::cost_today($r);
    }

    public function history_by_date($date, $month, $year){
        $sql = "Select * from $this->table order by $this->table.cost_date desc";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        $result = Utility::match_by_date($stmt->fetchAll(),$date, $month, $year, 'cost_date','cost_ammount');
        return $result;
    }

    public function deleteById($id){
        $sql = "Delete from `$this->table` where `$this->table`.`cost_id` = ?";
        $stmt = Database::$connection->prepare($sql);
        return $stmt->execute(array($id));
    }
}