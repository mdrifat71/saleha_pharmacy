<?php 
include_once 'Database.php';

class Customer extends Database{
    private $table = "customer_table";
    private $customer_id;
    private $customer_name;
    private $customer_address;
    private $customer_mobile;
    private $customer_due;
    private $customer_join_date;
    private $cutomer_type;
    
    public function __construct(){
        parent::__construct();
        $sql = 'CREATE TABLE IF NOT EXISTS customer_table ("customer_id"	TEXT,
        "customer_name"	TEXT,
        "customer_address"	TEXT,
        "customer_mobile"	INTEGER,
        "customer_due"	INTEGER,
        "customer_join_date"	DATETIME,
        "customer_type"	INTEGER,
        PRIMARY KEY("customer_id")
        )';

        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
    }

    public function validate($customer_name, $customer_address, $customer_mobile,$customer_type){
        if (empty($customer_name) or empty($customer_address) or empty($customer_mobile) or empty($customer_type) ){
            return false;
        }
        return true;
    }

    public function setter($customer_id,$customer_name, $customer_address, $customer_mobile, $customer_due,$customer_join_date, $customer_type){
        if ($this->validate($customer_name, $customer_address, $customer_mobile,$customer_type)){
            $this->customer_id = $customer_id;
            $this->customer_name = $customer_name;
            $this->customer_address = $customer_address;
            $this->customer_mobile = $customer_mobile;
            $this->customer_due = $customer_due;
            $this->customer_join_date = $customer_join_date;
            $this->customer_type = $customer_type;
            return true;
        }else{
            return false;
        }
        
    }

    public function selectAll(){
        $sql = "select * from `$this->table` order by `customer_name`";
        $stmt = Database::$connection->prepare($sql);
       
       try{
           $stmt->execute();
           return $stmt;
       }catch(PDOException $e)
       {
            return "Statement failed: " . $e->getMessage();
            
       }
    }

    public function count(){
        $sql = "select * from $this->table";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        return count($stmt->fetchAll());
    }

    public function total_due(){
        $sql = "select SUM(customer_due) as total_due from $this->table";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        $r = $stmt->fetch(PDO::FETCH_ASSOC);
        return $r['total_due'];
    
    }
    public function insert(){
        if(!empty($this->customer_due) or $this->customer_due != 0){
            $sql = "insert into `$this->table` (`customer_id`,`customer_name`, `customer_address`, `customer_mobile`, `customer_due`,`customer_join_date`, `customer_type`) values (:customer_id, :customer_name, :customer_address, :customer_mobile, :customer_due, :customer_join_date,:customer_type)";
            $stmt = Database::$connection->prepare($sql);
            $stmt->bindParam(":customer_id", $this->customer_id);
            $stmt->bindParam(":customer_name", $this->customer_name);
            $stmt->bindParam(":customer_address", $this->customer_address);
            $stmt->bindParam(":customer_mobile", $this->customer_mobile);
            $stmt->bindParam(":customer_due", $this->customer_due);
            $stmt->bindParam(":customer_join_date", $this->customer_join_date);
            $stmt->bindParam(":customer_type", $this->customer_type);
            
        }else{
            $sql = "insert into `$this->table` (`customer_id`,`customer_name`, `customer_address`, `customer_mobile`,`customer_join_date`, `customer_type`) values (:customer_id, :customer_name, :customer_address, :customer_mobile, :customer_join_date,:customer_type)";
            $stmt = Database::$connection->prepare($sql);
            $stmt->bindParam(":customer_id", $this->customer_id);
            $stmt->bindParam(":customer_name", $this->customer_name);
            $stmt->bindParam(":customer_address", $this->customer_address);
            $stmt->bindParam(":customer_mobile", $this->customer_mobile);
            $stmt->bindParam(":customer_join_date", $this->customer_join_date);
            $stmt->bindParam(":customer_type", $this->customer_type);
           
        }

       return $stmt->execute()  ;
    }

    public function updateById($customer_id,$due){
       if(is_numeric($due)){
        $sql = "UPDATE `$this->table` SET `customer_due` = `$this->table`.`customer_due` + $due WHERE `$this->table`.`customer_id` = '$customer_id' ";
        $stmt = Database::$connection->prepare($sql);
        return $stmt->execute();
       }else{
           return false;
       }
    }

    public function customer_due_by_id($id){
        $sql = "select `customer_due` from `$this->table` where `$this->table`.`customer_id` = ?";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute(array($id));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function no_due_customer(){
        $sql = "select `customer_due` from `$this->table` where `$this->table`.`customer_due` = 0";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        return count($stmt->fetchAll());
    }

    public function selectById($id){
        $sql = "select * from $this->table where customer_id = ?";
        $stmt= Database::$connection->prepare($sql);
        $stmt->execute(array($id));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    

    public function doctor_count(){
        $sql = "select * from $this->table where customer_type = 1";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        return count($stmt->fetchAll());
    }

    public function doctor_due(){
        $sql = "select SUM(customer_due) as total_due from $this->table where customer_type = 1";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        $r = $stmt->fetch(PDO::FETCH_ASSOC);
        return $r['total_due'];
    
    }

    public function update($customer_name, $customer_address, $customer_mobile, $customer_type,$customer_id){
        $sql = "Update $this->table 
                set `customer_name` = :customer_name,
                    `customer_address` = :customer_address,
                    `customer_mobile` = :customer_mobile,
                    `customer_type` = :customer_type
                where `customer_id` = :customer_id
        ";

        $stmt = Database::$connection->prepare($sql);
        $stmt->bindParam(":customer_name", $customer_name);
        $stmt->bindParam(":customer_address", $customer_address);
        $stmt->bindParam(":customer_mobile", $customer_mobile);
        $stmt->bindParam(":customer_type", $customer_type);
        $stmt->bindParam(":customer_id", $customer_id);
        return $stmt->execute();
      
    }

    public function deleteByCustomer($id){
        $sql = "Delete from `$this->table` where `customer_id` = ?";
        $stmt = Database::$connection->prepare($sql);
        return $stmt->execute(array($id));
    }

    
}

