<?php

class Database {
    public function __construct(){
        self::connect();
    }

   
    public static $connection;
    public static function connect(){
        $root = $_SERVER['DOCUMENT_ROOT'];
        $dsn = "sqlite:$root/db/saleha_pharmacy.db";
        try{
            self::$connection = new PDO($dsn);
            self::$connection->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            self::$connection->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
        
        }catch(PDOException $e){
            echo "<pre>";
            print_r($e);
            echo "</pre>";
        }
    
    }
}


