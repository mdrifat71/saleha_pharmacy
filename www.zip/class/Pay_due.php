<?php 
include_once 'Database.php';
class Pay_due extends Database{
    private $table = 'payment_table';
    private $payment_id;
    private $customer_id;
    private $payment_ammount;
    private $payment_date;

    public function __construct(){
        parent::__construct();
    }
    public function setter($payment_id, $payment_ammount, $customer_id,$payment_date){
        if($this->validate($payment_id, $payment_ammount, $customer_id,$payment_date)){
            $this->payment_id = $payment_id;
            $this->payment_ammount = $payment_ammount;
            $this->customer_id = $customer_id;
            $this->payment_date = $payment_date;
            return true;
        }
        else{
            return false;
        }
    }

    public function validate($payment_id,$payment_ammount, $customer_id, $payment_date){
        if (empty($payment_id) or empty($payment_ammount) or empty($customer_id) or empty($payment_date)){
            return false;
        }
        return true;
    }

    public function insert(){
        
        $sql = "insert into `$this->table` (`payment_id`, `customer_id`, `payment_ammount`, `payment_date`) values (?,?,?,?)";
        $data = array($this->payment_id, $this->customer_id, $this->payment_ammount, $this->payment_date);
        $stmt= Database::$connection->prepare($sql);
        return $stmt->execute($data);
        
    }

    public function deleteById($id){
        $sql = "Delete from `$this->table` where `$this->table`.`payment_id` = ?";
        $stmt = Database::$connection->prepare($sql);
        return $stmt->execute(array($id));
    }

    public function payment_history(){
        $sql = "Select $this->table.*, customer_table.customer_name from $this->table inner join customer_table on $this->table.customer_id = customer_table.customer_id order by $this->table.payment_date desc limit 100";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function selectById($id){
        $sql = "select * from $this->table where customer_id = ? order by payment_date desc";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute(array($id));
       return $stmt->fetchAll();

    }
    
    public function count(){
        $sql = "select * from $this->table";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        return count($stmt->fetchAll());
    }

    public function deleteByCustomerId($id){
        $sql = "Delete from `$this->table` where `$this->table`.`customer_id` = ?";
        $stmt = Database::$connection->prepare($sql);
        return $stmt->execute(array($id));
    }

    public function deleteByCustomer($id){
        $sql = "Delete from `$this->table` where `customer_id` = ?";
        $stmt = Database::$connection->prepare($sql);
        return $stmt->execute(array($id));
    }

    public function history_by_date($date, $month, $year ){
        $sql = "Select $this->table.*, customer_table.customer_name from $this->table inner join customer_table on $this->table.customer_id = customer_table.customer_id order by $this->table.payment_date desc";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        $result = Utility::match_by_date($stmt->fetchAll(),$date, $month, $year, 'payment_date','payment_ammount');
        return $result;
    }
}