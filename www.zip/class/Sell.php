<?php

include_once "Database.php";
include_once "Utility.php";

class Sell extends Database{
    public function __construct(){
        parent::__construct();
    }
    
    private $table = "sell_table";
    private $sell_id;
    private $sell_ammount;
    private $sell_date;

    public function setter($sell_id, $sell_ammount,$sell_date){
        $this->sell_id = $sell_id;
        $this->sell_ammount = $sell_ammount;
        $this->sell_date = $sell_date;
        return true;
    }

    public function insert(){
        $sql = "insert into $this->table (`sell_id`, `sell_ammount`, `sell_date`) values (:sell_id, :sell_ammount, :sell_date)";
        $stmt = Database::$connection->prepare($sql);
        $stmt->bindParam(":sell_id", $this->sell_id);
        $stmt->bindParam(":sell_ammount", $this->sell_ammount);
        $stmt->bindParam(":sell_date", $this->sell_date);
        return $stmt->execute();
    }

    public function sell_today(){
        $sql = "select * from $this->table";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        $r = $stmt->fetchAll();
        return Utility::sell_today($r);
    }

    public function history_by_date($date, $month, $year){
        $sql = "Select * from $this->table order by sell_date desc";
        $stmt = Database::$connection->prepare($sql);
        $stmt->execute();
        $result = Utility::match_by_date($stmt->fetchAll(),$date, $month, $year, 'sell_date','sell_ammount');
        return $result;
    }

    public function deleteById($id){
        $sql = "Delete from `$this->table` where `$this->table`.`sell_id` = ?";
        $stmt = Database::$connection->prepare($sql);
        return $stmt->execute(array($id));
    }
}