<?php

class Session{
    public function __construct(){
       
    }

    public static function set($index, $value){
        
        $_SESSION[$index] = $value;
    }

    public static function get($index){
        
        if(isset( $_SESSION[$index])){
            return $_SESSION[$index];
        }
        return -1;
    }

    public static function check($index, $value){
        
        if(isset($_SESSION[$index]) and $_SESSION[$index] == $value){
            return true;
        }
        return false;
    }

    public function destroy(){
        session_destroy();
    }

    public static function unset($index){
        unset($_SESSION[$index]);
    }
}