<?php 
date_default_timezone_set('Asia/Dhaka');
class Utility{
    public static function date($format){
        $arr_month = array("January","February", "March", "April", "May", "June", "July", "August", "September", "October", "November","December"
        );
        $arr_main = explode(" ",$format);
        $date_data = $arr_main[0];
        $time_data = $arr_main[1];

        $arr_date = explode(":", $date_data);
        $date = $arr_date[2];
        $month = $arr_month[(int)$arr_date[1]-1];
        $year = $arr_date[0];
        $arr_time = explode(":",$time_data);

        $hour = $arr_time[0];
        $minute = $arr_time[1];

        $full_date = "$date $month, $year $hour:$minute";
        return $full_date;
        
    }

    public static function date_str($str){
        $d= explode(" ", $str)[0];
        return explode(":", $d)[2];
    }

    public static function month_str($str){
        $d = explode(" ", $str)[0];
        return explode(":",$d)[1];
    }

    public static function year_str($str){
        $d = explode(" ", $str)[0];
        return explode(":",$d)[0];
    }
    public static function due_today($arr){
        $sum = 0;
        foreach($arr as $item){
            
            $date = self::date_str($item['due_date']);
            $today = date("d");
            if($date == $today ){
                $sum += (int)$item['due'];
            }
        }
        return $sum;
    }

    public static function due_this_month($arr){
        $sum = 0;
        
        $month = date("m");
        foreach($arr as $item){
           
            $this_month = self::month_str($item['due_date']);
            if($month == $this_month ){
                $sum += (int)$item['due'];
            }else{
               
            }
        }
        return $sum;
    }

    public static function sell_this_month($arr){
        $sum = 0;
        
        $month = date("m");
        foreach($arr as $item){
           
            $this_month = self::month_str($item['due_date']);
            if($month == $this_month ){
                $sum += (int)$item['due'];
            }else{
                echo "$month <br>";
            }
        }
        return $sum;
    }

    public static function sell_today($arr){
        $sum = 0;
        foreach($arr as $item){
            
            $date = self::date_str($item['sell_date']);
            $today = date("d");
            if($date == $today ){
                $sum += (int)$item['sell_ammount'];
            }
        }
        return $sum;
    }

    public static function cost_today($arr){
        $sum = 0;
        foreach($arr as $item){
            
            $date = self::date_str($item['cost_date']);
            $today = date("d");
            if($date == $today ){
                $sum += (int)$item['cost_ammount'];
            }
        }
        return $sum;
    }

    public static function match_by_date($arr,$date, $month, $year, $field, $sum_field){
        $output = array();
        $info = array();
        $sum = 0;
        if ((int)$date <= 0){
            //if user input no date
            foreach($arr as $row){
                $due_date = $row[$field];
                $formated_date = self::date($due_date);
                //form date 
                $row_date = (int)self::date_str($due_date);
                $row_month = (int)self::month_str($due_date);
                $row_year =(int) self::year_str($due_date);
    
                //user typed date
                $date = (int) $date;
                $month = (int) $month;
                $year = (int) $year;
                
                if($month == $row_month and $year == $row_year){
                    $row['date'] = $formated_date;
                    array_push($output, $row);
                    $sum += (int) $row[$sum_field];
                }
            }
        }elseif((int) $month <=0){
            //if user input no month
            foreach($arr as $row){
                $due_date = $row[$field];
                $formated_date = self::date($due_date);
                //form date 
                $row_date = (int)self::date_str($due_date);
                $row_month = (int)self::month_str($due_date);
                $row_year =(int) self::year_str($due_date);
    
                //user typed date
                $date = (int) $date;
                $month = (int) $month;
                $year = (int) $year;
                
                if($year == $row_year){
                    $row['date'] = $formated_date;
                    array_push($output, $row);
                    $sum += (int) $row[$sum_field];
                }
            }
        }else{
            foreach($arr as $row){
                $due_date = $row[$field];
                $formated_date = self::date($due_date);
                //form date 
                $row_date = (int)self::date_str($due_date);
                $row_month = (int)self::month_str($due_date);
                $row_year =(int) self::year_str($due_date);
    
                //user typed date
                $date = (int) $date;
                $month = (int) $month;
                $year = (int) $year;
                
                if($date == $row_date and $month == $row_month and $year == $row_year){
                    $row['date'] = $formated_date;
                    array_push($output, $row);
                    $sum += (int) $row[$sum_field];
                }
            }
        }

         array_push($info,$output);
         array_push($info, $sum);
         return $info;
        
    }
}
