<?php
session_start();
include_once 'class/Session.php';
if(Session::check("login", "true")){
    $user_name= Session::get("username");
}else{
    header("location:login.php");
}

include_once 'class/Company.php';
include_once 'class/Utility.php';
include_once 'class/Company_due.php';
include_once 'class/Company_payment.php';

$company_due = new Company_due;
$company_payment = new Company_payment;
$company = new Company;

if(isset($_POST['add_company'])){
    $company_id = md5(uniqid());
    $company_name = $_POST['company_name'];
    $representative_name = $_POST['representative_name'];
    $representative_mobile = $_POST['representative_mobile'];
    $due = $_POST['company_due'];
    if(!empty($company_id) and !empty($company_name) and !empty($representative_name) and !empty($representative_mobile)){
        if($company->setter($company_id, $company_name, $due, $representative_name, $representative_mobile)){
            if(!$company->isCompanyExist($company_name)){
                if($company->insert()){
                    Session::set("inserted","true");
                }else{
                    Session::set("inserted", "false");
                }
            }
        }
    }
}


if(isset($_POST['delete_company'])){
    $company_id = $_POST['company_id'];
    $password = Session::get("password");
    $get_password = $_POST['password'];

    if($password == $get_password){
        if($company->deleteById($company_id)){
            if($company_due->deleteByCompanyId($company_id) and $company_payment->deleteByCompanyId($company_id)){
                Session::set("deleted", "true");
            }
            
        }else{
            Session::set("deleted", "false");
        }
    }
}

$total_company = $company->count();
$total_company_due = $company->total_due();
$all_company_name = $company->all_company();
$company_list = $company->selectAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="icons/css/all.css">
    <link rel="stylesheet" href="css/style.css?<?php echo date('Y-m-d_H:i:s'); ?>">
</head>
<body class="bg-light">
    
    <!--header start-->
    <section id = "header" style="position:sticky; z-index:1000000;;top:0">
        <div class=" btn-block bg-warning text-center" style ="letter-spacing:3px">
            SALEHA PHARMACY
        </div>
        <div class="container">
           
                <ul>
                    <li class="">
                        <a href="index.php" >
                            <i class="fa fa-address-book  menu-icon"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="customer_list.php">
                            <i class="fa fa-users  menu-icon"></i>
                            <span>Customer List</span>
                        </a>
                    </li>
                    <li>
                        <a href="add_customer.php">
                            <i class="fa fa-plus menu-icon"> <i class="fa fa-users"></i></i>
                            <span>Add customer</span>
                        </a>
                    </li>
                    <li>
                        <a href="add_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-briefcase  menu-icon"></i></i>
                            <span>Add due</span>
                        </a>
                    </li>
                    <li>
                        <a href="pay_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-credit-card  menu-icon"></i></i>
                            <span>Pay due</span>
                        </a>
                    </li>
                    <li class="logout">
                        <a href="logout.php?logout">
                            <i class="fa fa-sign-out  menu-icon"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                    <li class="back">
                        <button class="btn " onclick="history.go(-1)"><i class=" fa fa-arrow-left"></i></button>
                    </li>
                </ul>
            
        </div>
    </section>

    <!--header end-->
    <!--2nd header-->
    
    <section id="s-header">
        <div class="container mt-4">
            <div class="row">
                <div class="col-4">
                    <h3 class="text-uppercase">Company List</h3>
                    <h6 class="display-5 text-uppercase">Total Company : <b><?php echo $total_company?></b> </h6>
                    <h6 class="display-5 text-uppercase">Company Due : <b><?php echo $total_company_due?>৳</b> </h6>
                </div>
                <div class="col-4 search">
                    <form class="form-inline d-flex justify-content-center md-form form-sm mt-4 active-info">
                        <input id = "search_company" class="form-control form-control-sm ml-3 w-75 search-input" type="text" placeholder="Search"
                          aria-label="Search">
                      </form>
                </div>
                <div class="col-4 d-flex">
                    <span class="d-inline-block ml-auto company_add_btn">
                        <button class="btn btn-success mt-3 ">
                            <i class="fa fa-plus"></i>
                            <span class ="">Add Company</span>
                        </button>
                    </span>
                </div>
            </div>
        </div>
    </section>

    <!--2nd header end-->

    <hr class="line">

    <section id = "customer-table">
        <div class="container">
               
               <div>
                    

                        <div class="alert alert-success mt-3 msg_btn_r <?php if(!Session::check("inserted","true")) echo 'd-hid'; Session::set('inserted',3);?>">Added successfully</div>
                   
                        <div class="alert alert-danger mt-3 msg_btn_w <?php if(!Session::check("inserted","false")) echo 'd-hid'; Session::set('inserted',3);?>">Not Added</div>
                        <div class="alert alert-success mt-3 msg_btn_r <?php if(!Session::check("deleted","true")) echo 'd-hid'; Session::set('deleted',3);?>">Deleted successfully</div>
                   
                        <div class="alert alert-danger mt-3 msg_btn_w <?php if(!Session::check("deleted","false")) echo 'd-hid'; Session::set('deleted',3);?>">Not Deleted</div>

                    
               </div>
              <table class="table mt-2">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Company Name</th>
                    <th scope="col">Representative Name</th>
                    <th scope="col">Representative Mobile</th>
                    <th scope="col">Due (৳)</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                    
                <?php 
                    $count = 1;
                    if (!empty($company_list)){
                ?>
                <?php 
                    foreach($company_list as $result){
                ?>
                  <tr class="font-weight-bold company_info" >
                    <th scope="row"><?php echo $count?></th>
                    <td class =""> <i class="mr-2 fa fa-industry"></i> <a class = "all_company_name" href="company_profile.php?id=<?php echo $result['company_id']?>" class="font-weight-bold">   <?php echo $result['company_name']?> </a></td>
                    <td><?php echo $result['representative_name']?></td>
                    <td class=""><?php echo $result['representative_mobile']?></td>
                    <td class="font-weight-bold text-success"><?php echo $result['company_due']?></td>
                    <td class="font-weight-bold text-success "><button class="btn-danger btn btn-sm company_del_btn" title = "delete company" style = "font-size:12px" customer_id = <?php echo $result['company_id']?>><i class="fa fa-times" ></i></button></td>
                  </tr>
                <?php 
                    $count++;
                    }
                }
                ?>
                
                </tbody>
              </table>
              <div class="no-data alert alert-danger d-hid">
                    <td>No Company Found !!</td>
                </div>
        </div>
    </section>
  
    <!--modal -->
    <div id="modal" class="d-hid  modal_1" style=>
            <div class="modal-container">
                <div class="card add_company_modal">
                    <div class="card-header bg-success text-center text-light font-weight-normal">
                       Add Company
                    </div>

                    <div class="card-body bg-dark text-light">
                    <form action="" method = "post">
                            <div class="form-group">
                                <label for="company_name">Company Name</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fa fa-building"></i></span>
                                    </div>
                                    <input type="text" class="form-control" id="company_name" placeholder="Company Name" name ="company_name">
                                    
                                </div>
                                <span class="company_exist text-danger mt-1 d-hid d-inline-block">Company Exist</span>
                                
                              </div>
                            <div class="form-row">
                              <div class="form-group col-md-6">
                                <label for="customer_address">Representative Name</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fa fa-user"></i></span>
                                    </div>
                                    <input type="text" class="form-control" id="representative_name" placeholder="Representative Name" name = "representative_name">
                                </div>
                                
                              </div>
                              <div class="form-group col-md-6">
                                <label >Representative Contact</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fa fa-phone"></i></span>
                                    </div>
                                    <input type="number" class="form-control"  id = "representative_mobile" placeholder="Contact" name = "representative_mobile">
                                </div>
                              </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                  <label for="">Previous Due</label>
                                  <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">৳</i></span>
                                    </div>
                                    <input type="number" class="form-control" id="company_due" placeholder="Due" name = "company_due"> 
                                  </div>                                  
                                </div>
                                
                                
                              </div>
                            
                            <button type="submit" class="btn btn-success btn-sm" name ="add_company" id = "add_company" disabled>ADD</button>
                            <button type="" class="btn btn-danger cancel_btn btn-sm" name ="" id = "company_add_btn">Cancel</button>
                          </form>
                    </div>
                </div> 
            </div>
    </div>

    <div id="modal" class="d-hid modal_2" style="height:500px;">
            <div class="modal-container">
                <div class="card payment-modal">
                    <div class="card-header bg-danger text-center text-light font-weight-normal">
                        Enter Password to Confirm
                    </div>

                    <div class="card-body">
                        <form action="" method = "post" >
                            <button class="btn btn-danger btn-sm mb-2 delete_company "></button>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fa fa-key"></i></span>
                                </div>
                                <input type="hidden" class="company_id_field" value ="" name="company_id">
                                <input type="password" name = "password" class="form-control customer_payment">
                               
                            </div>
                            <button class="mt-3 btn btn-danger submit_btn btn-sm" name= "delete_company"  >Delete</button>
                            <button class="mt-3 btn btn-success cancel_btn btn-sm">Cancel</button>
                        </form>
                    </div>
                </div> 
            </div>
    </div>
    <script src="js/company_list.js?id=<?php echo date('i-m-y') ?>"></script>
    <script src="js/all.js?v=<?php echo date('d-m-i') ?>"></script>
</body>
</html>