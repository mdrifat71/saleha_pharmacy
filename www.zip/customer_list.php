<?php
session_start();
include_once 'class/Session.php';
if(Session::check("login", "true")){
    $user_name= Session::get("username");
}else{
    header("location:login.php");
}
include_once 'class/Customer.php';
include_once 'class/Pay_due.php';
include_once 'class/Add_due.php';
include_once 'class/Utility.php';
$customer = new Customer;
$pay_due = new Pay_due;
$add_due = new Add_due;
Session::set("deleted", 0);
Session::set("wrong_pass", 0);

if(isset($_POST['submit_btn']) and !empty($_POST['password'])){
    $password = $_POST['password'];
    $admin_password = Session::get("password");
    $id = $_POST['customer_id'];
    if($password == $admin_password){
        if($pay_due->deleteByCustomer($id)){
            if($add_due->deleteByCustomer($id)){
                $customer->deleteByCustomer($id);
                Session::set("deleted", 1);
            }else{
                Session::set("deleted",0);
            }
        }else{
            
        }
    }else{
        Session::set("wrong_pass",1);
    }
}

//echo Session::get("deleted");
$results = $customer->selectAll();
$row_count = $customer->count();
$total_due = $customer->total_due();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="icons/css/all.css">
    <link rel="stylesheet" href="css/style.css?<?php echo date('Y-m-d_H:i:s'); ?>">
</head>
<body class="bg-light">
    
    <!--header start-->
    <section id = "header" style="position:sticky; z-index:1000000;;top:0">
        <div class=" btn-block bg-warning text-center" style ="letter-spacing:3px">
            SALEHA PHARMACY
        </div>
        <div class="container">
           
                <ul>
                    <li class="">
                        <a href="index.php" >
                            <i class="fa fa-address-book  menu-icon"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="a-menu">
                        <a href="">
                            <i class="fa fa-users  menu-icon"></i>
                            <span>Customer List</span>
                        </a>
                    </li>
                    <li>
                        <a href="add_customer.php">
                            <i class="fa fa-plus menu-icon"> <i class="fa fa-users"></i></i>
                            <span>Add customer</span>
                        </a>
                    </li>
                    <li>
                        <a href="add_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-briefcase  menu-icon"></i></i>
                            <span>Add due</span>
                        </a>
                    </li>
                    <li>
                        <a href="pay_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-credit-card  menu-icon"></i></i>
                            <span>Pay due</span>
                        </a>
                    </li>
                    <li class="logout">
                        <a href="logout.php?logout">
                            <i class="fa fa-sign-out  menu-icon"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                    <li class="back">
                        <button class="btn " onclick="history.go(-1)"><i class=" fa fa-arrow-left"></i></button>
                    </li>
                </ul>
            
        </div>
    </section>

    <!--header end-->
    <!--2nd header-->
    
    <section id="s-header">
        <div class="container mt-4">
            <div class="row">
                <div class="col-4">
                    <h3 class="text-uppercase">Customer List</h3>
                    <h6 class="display-5 text-uppercase">Total customer : <b><?php echo $row_count?></b> </h6>
                    <h6 class="display-5 text-uppercase">Total Due : <b><?php echo $total_due?>৳</b> </h6>
                </div>
                <div class="col-4 search">
                    <form class="form-inline d-flex justify-content-center md-form form-sm mt-4 active-info">
                        <input id = "search_customer" class="form-control form-control-sm ml-3 w-75 search-input" type="text" placeholder="Search"
                          aria-label="Search">
                      </form>
                </div>
                <div class="col-4 d-flex">
                    <a href="add_customer.php" class="d-inline-block ml-auto">
                        <button class="btn btn-primary mt-3 ">
                            <i class="fa fa-plus"></i>
                            <span>Add Customer</span>
                        </button>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!--2nd header end-->

    <hr class="line">

    <section id = "customer-table">
        <div class="container">
               <div class="">
                    <span class="btn btn-danger btn-sm all_sort sort_btn sort_btn">All</span>
                    <span class="btn btn-primary btn-sm customer_sort sort_btn">Customer</span>
                    <span class="btn btn-primary btn-sm doctor_sort sort_btn">Doctor</span>
                    <span class="btn btn-primary btn-sm no_due_sort sort_btn">No Due Customer</span>
                    <span class="btn btn-primary btn-sm due_sort sort_btn">Due Customer</span>
               </div>
               <div>
                    

                        <div class="alert alert-success mt-3 msg_btn_r <?php if(!Session::check("deleted",1)) echo 'd-hid'; Session::set('deleted',3);?>">Deleted successfully</div>
                   
                        <div class="alert alert-danger mt-3 msg_btn_w <?php if(!Session::check("wrong_pass",1)) echo 'd-hid'; Session::set('wrong_pass',3);?>">Not Deleted,Wrong Password!!</div>

                    
               </div>
              <table class="table mt-2">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Adress</th>
                    <th scope="col">Mobile</th>
                    <th scope="col">Due (৳)</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                    
                <?php 
                    $count = 1;
                    if (!empty($results)){
                ?>
                <?php 
                    foreach($results as $result){
                ?>
                  <tr class="font-weight-bold customer_info" type = "<?php if($result['customer_type'] == 1) echo "doctor"; else echo "customer";?>">
                    <th scope="row"><?php echo $count?></th>
                    <td class =""> <i class="mr-2 <?php if($result['customer_type'] == 1) echo "fa fa-user-md text-danger"; else echo "fa fa-wheelchair"; ?>"></i> <a href="customer_profile.php?id=<?php echo $result['customer_id']?>" class="font-weight-bold">   <?php echo $result['customer_name']?> </a></td>
                    <td><?php echo $result['customer_address']?></td>
                    <td class=""><?php echo $result['customer_mobile']?></td>
                    <td class="font-weight-bold text-success"><?php echo $result['customer_due']?></td>
                    <td class="font-weight-bold text-success "><button class="btn-danger btn btn-sm customer_del_btn" title = "delete customer" style = "font-size:12px" customer_id = <?php echo $result['customer_id']?>><i class="fa fa-times" ></i></button></td>
                  </tr>
                <?php 
                    $count++;
                    }
                }
                ?>
                
                </tbody>
              </table>
              <div class="no-data alert alert-danger d-hid">
                    <td>No customer found</td>
                </div>
        </div>
    </section>
    
    <div id="modal" class="d-hid f" style="height:500px;">
            <div class="modal-container">
                <div class="card payment-modal">
                    <div class="card-header bg-danger text-center text-light font-weight-normal">
                        Enter Password to Confirm
                    </div>

                    <div class="card-body">
                        <form action="" method = "post" >
                            <button class="btn btn-danger btn-sm mb-2 delete_user "></button>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fa fa-key"></i></span>
                                </div>
                                <input type="hidden" class="customer_id_field" value ="" name="customer_id">
                                <input type="password" name = "password" class="form-control customer_payment">
                               
                            </div>
                            <button class="mt-3 btn btn-danger submit_btn btn-sm" name= "submit_btn"  >Delete</button>
                            <button class="mt-3 btn btn-success cancel_btn btn-sm">Cancel</button>
                        </form>
                    </div>
                </div> 
            </div>
    </div>

    
    
    <script src="js/customer_list.js?id=<?php echo date('i-m-y') ?>"></script>
    <script src="js/all.js?v=<?php echo date('d-m-i') ?>"></script>
</body>
</html>