<?php
session_start();
include_once 'class/Session.php';
if(Session::check("login", "true")){
    $user_name= Session::get("username");
}else{
    header("location:login.php");
}
include 'class/Customer.php';
include 'class/Add_due.php';
include 'class/Pay_due.php';
include_once 'class/Utility.php';
$customer = new Customer;
$add_due = new Add_due;
$pay_due = new Pay_due;

if(isset($_POST['pay_btn']) && isset($_POST['customer_payment']) ){
   
    date_default_timezone_set("Asia/Dhaka");
    $customer_id = $_POST['customer_id'];
    $customer_payment = $_POST['customer_payment'];
    $payment_id = md5(uniqid());
    $payment_date = date('Y:m:d h:i:s');
    if($pay_due->setter($payment_id, $customer_payment, $customer_id,$payment_date)){
        if($pay_due->insert()){
            $success = true;
            $customer->updateById($customer_id, -1*$customer_payment);//update due
            $_POST['customer_payment'] = null;
        }else{
            $success = false;
        }
        
    }else{
        $success = false;
    }
}


if(isset($_GET['id']) and !empty($_GET['id'])){
    $id = $_GET['id'];
    $result = $customer->selectById($id);
    $customer_name = $result['customer_name'];
    $customer_due  = $result['customer_due'];
    $customer_mobile = $result['customer_mobile'];
    $customer_address = $result['customer_address'];
    $customer_type = $result['customer_type'];

    $payment_history = $pay_due->selectById($id);
    $due_history = $add_due->selectById($id);

    /*
    $payment_history_count = $pay_due->count();
    $due_history_count = $add_due->count();
    */

}else{
    header("location:index.php");
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="icons/css/all.css">
    <link rel="stylesheet" href="css/style.css?<?php echo date('Y-m-d_H:i:s'); ?>">
</head>
<body class="bg-light">
    
    <!--header start-->
    <section id = "header" style="position:sticky; z-index:1000000;;top:0">
        <div class=" btn-block bg-warning text-center" style ="letter-spacing:3px">
            SALEHA PHARMACY
        </div>
        <div class="container">
           
                <ul>
                    <li class="">
                        <a href="index.php" >
                            <i class="fa fa-address-book  menu-icon"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="customer_list.php">
                            <i class="fa fa-users  menu-icon"></i>
                            <span>Customer List</span>
                        </a>
                    </li>
                    <li>
                        <a href="add_customer.php">
                            <i class="fa fa-plus menu-icon"> <i class="fa fa-users"></i></i>
                            <span>Add customer</span>
                        </a>
                    </li>
                    <li>
                        <a href="add_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-briefcase  menu-icon"></i></i>
                            <span>Add due</span>
                        </a>
                    </li>
                    <li>
                        <a href="pay_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-credit-card  menu-icon"></i></i>
                            <span>Pay due</span>
                        </a>
                    </li>
                    <li class="logout">
                        <a href="logout.php?logout">
                            <i class="fa fa-sign-out  menu-icon"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                    <li class="back">
                        <button class="btn " onclick="history.go(-1)"><i class=" fa fa-arrow-left"></i></button>
                    </li>
                </ul>
            
        </div>
    </section>

    <!--header end-->

    <!--main start-->
    <section id="main">
        <div class="container">
            <div class="row mt-4">
                <div class="col-12">
                    <div class="card">

                        <div class="row">
                            <div class="col-md-4">
                                <div class="card">
                                    <img src="user.png" alt="" class="card-img-top ">
                                    <div class="card-body">
                                    <p class="font-weight-bold "><i class="<?php if($customer_type == 1) echo "fa fa-user-md text-danger"; else echo "fa fa-wheelchair" ?> mr-2 "></i> <?php echo $customer_name; ?> <?php if($customer_type == 1) echo "<span class='badge badge-danger ml-3'>Doctor</span>"; ?> <a href="edit_info.php?id=<?php echo $id?>"><i title = "edit info" class="fa fa-pen edit-icon ml-5"></i></a></p>
                                    <button class="btn btn-sm btn-success pay_modal_btn" <?php if($customer_due <= 0) echo "disabled" ?>>Pay Due</button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8 mt-4">
                               <div class="row">
                                    <div class="col-md-6">
                                        <div class="btn btn-success btn-block mb-3 rounded-0">Customer Info</div>
                                        <div class="d-flex flex-row customer_details ml-4">
                                            <i class="fa fa-phone mr-4"></i>
                                            <p class="font-weight-bold"><?php echo $customer_mobile?></p>
                                        </div>
                                        <div class="d-flex flex-row customer_details ml-4">
                                            <i class="fa fa-map-marker  mr-4"></i>
                                            <p class="font-weight-bold"><?php echo $customer_address?></p>
                                        </div>
                                        

                                    </div>
                                    <div class="col-md-6">
                                        <div class="due-card mr-4 ml-4 text-center">
                                            <div class="btn btn-danger btn-block rounded-0"> Due</div>
                                            <div class="mt-4   font-weight-bold  display-4"><?php echo $customer_due?>৳</div>
                                            
                                         </div>
                                    </div>
                               </div>
                               
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--main end-->

    <section id="history">
        <div class="container">
            <div class="row mt-3 mb-4">
                <div class="col-lg-6">
                    <div class="btn btn-success btn-block rounded-0">Payment History</div>
                    
                        <button class="btn btn-sm btn-danger  mt-2 mb-2 clear_all_payment_history <?php if(empty($payment_history)) echo "d-hid" ?>"> <i class="fa fa-trash"></i> clear all</button>
                        <input type="number" style = "width:30%; font-size:12px" class="form-control d-inline mt-1 payment_history_count" value = "5" title = "history count" placeholder = "history count">

                    <div class="payment_history">
                        <?php 

                            if(!empty($payment_history)){
                                foreach($payment_history as $item){
                        ?>
                            <div class="alert alert-success payment_history_item d-flex mb-0"> <div class="ammount"><?php echo $item['payment_ammount'] ?></div>৳  <div class="date"><?php echo Utility::date($item['payment_date'])?></div> <button class="btn btn-sm btn-danger clear_payment_history_btn" payment_id ="<?php echo $item['payment_id'] ?>"><i class="fa fa-times"></i></button> </div>
                        
                        <?php
                                }
                            }   
                        ?>
                        <div class="alert alert-primary no_payment <?php if(!empty($payment_history)) echo "d-hid" ?>">No Payment History</div>
                       
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="btn btn-danger btn-block rounded-0">Due History</div>
                    
                        <button class="btn btn-sm btn-danger  mt-2 mb-2 clear_all_due_history  <?php if(empty($due_history)) echo "d-hid" ?>"> <i class="fa fa-trash"></i> clear all</button>
                        <input type="number" style = "width:30%; font-size:12px" class="form-control d-inline mt-1 due_history_count" value = "5" title = "history count" placeholder = "history count">
                    
                    <div class="due-history">
                         <?php 
                            if(!empty($due_history)){
                                foreach($due_history as $item){
                        ?>
                         <div class="alert alert-danger due_history_item d-flex mb-0"> <div class="ammount"><?php echo $item['due'] ?></div>৳  <div class="date"><?php echo  Utility::date($item['due_date'])?></div> <button class="btn btn-sm btn-danger clear_due_history_btn" due_id = "<?php echo $item['due_id'] ?>"><i class="fa fa-times"></i></button> </div>
                         <?php
                                }
                            }  
                        ?>
                         <div class="alert alert-primary no_due <?php if(!empty($due_history)) echo "d-hid" ?>">No Due History</div>
                        
                    </div>
                   
                </div>
            </div>

        </div>

        <div class="d-hid customer_id"><?php  echo $id ?></div>
    </section>

<!--modal -->
    <div id="modal" class="d-hid f" style="height:500px;">
            <div class="modal-container">
                <div class="card payment-modal">
                    <div class="card-header bg-success text-center text-light font-weight-normal">
                        Payment Ammount
                    </div>

                    <div class="card-body">
                        <form action="" method = "post">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">৳</span>
                                </div>
                                <input type="number" name = "customer_payment" class="form-control customer_payment" customer_due ="<?php echo $customer_due?>">
                                <input type="hidden" name = "customer_id" class="form-control" value = "<?php echo $id;?>">
                            </div>
                            <button class="mt-3 btn btn-success pay_btn btn-sm" name= "pay_btn" <?php if($customer_due == 0) echo "disabled" ?> disabled >Pay</button>
                            <button class="mt-3 btn btn-danger cancel_btn btn-sm">Cancel</button>
                        </form>
                    </div>
                </div> 
            </div>
    </div>
    <div class="btn-block  py-2 footer bg-dark text-center text-light" style ="text-transform:uppercase; letter-spacing:3px; font-size:12px;">&copy MD Rifat Sarker</div>
    <script src="js/customer_profile.js?id=<?php echo date("d-m-y-s")?>"></script>
    <script src="js/all.js?v=<?php echo date('d-m-i') ?>"></script>
</body>
</html>