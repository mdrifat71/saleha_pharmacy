<?php
session_start();
include_once 'class/Session.php';
if(Session::check("login", "true")){
    $user_name= Session::get("username");
}else{
    header("location:login.php");
}
include 'class/Company.php';


$company = new Company;
$id = '';
if(isset($_GET['id']) and !empty($_GET['id'])){
    $id = $_GET['id'];
    $company_names = $company->selectAll();

}else{
    header("location:index.php");
}

if(isset($_POST['update'])){
    $company_name = $_POST['company_name'];
    $representative_name = $_POST['representative_name'];
    $representative_mobile = $_POST['representative_mobile'];

    if (!empty($company_name) and !empty($representative_name) and !empty($representative_mobile) ){
    
        
        if($company->update($company_name, $representative_name, $representative_mobile,$id)){
            header("location:company_profile.php?id=$id");
            
        }else{
            $err = true;
        }
    }
}
$company_info = $company->selectById($id);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="icons/css/all.css">
    <link rel="stylesheet" href="css/style.css?<?php echo date('Y-m-d_H:i:s'); ?>">
</head>
<body class="bg-light">
    
    <!--header start-->
    <section id = "header" style="position:sticky; z-index:1000000;;top:0">
        <div class=" btn-block bg-warning text-center" style ="letter-spacing:3px">
            SALEHA PHARMACY
        </div>
        <div class="container">
           
                <ul>
                    <li class="">
                        <a href="index.php" >
                            <i class="fa fa-address-book  menu-icon"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="customer_list.php">
                            <i class="fa fa-users  menu-icon"></i>
                            <span>Customer List</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="add_customer.php">
                            <i class="fa fa-plus menu-icon"> <i class="fa fa-users"></i></i>
                            <span>Add customer</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="add_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-briefcase  menu-icon"></i></i>
                            <span>Add due</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="pay_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-credit-card  menu-icon"></i></i>
                            <span>Pay due</span>
                        </a>
                    </li>
                    <li class="logout">
                        <a href="logout.php?logout">
                            <i class="fa fa-sign-out  menu-icon"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                    <li class="back">
                        <button class="btn " onclick="history.go(-1)"><i class=" fa fa-arrow-left"></i></button>
                    </li>
                    
                </ul>
            
        </div>
    </section>

    <!--header end-->

    <!--add due-->

    <section id="add-customer">
        <div class="container">
           <div class="row">
               <div class="col-lg-2"></div>
               <div class="col-lg-8 mb-4">
                <div class="card mt-5 bg-dark text-white">
                    <div class="card-header">
                        <h4>CUSTOMER DETAILS</h4>
                    </div>
                    <div class="card-body customer-form">
                        <form action="" method = "post">
                            <div class="form-group">
                                <label for="customer_name">Company Name</label>
                                <input value = "<?php echo $company_info['company_name']?>" type="text" class="form-control" id="company_name" placeholder="Company Name" name ="company_name">
                                 <!--company exists -->     <div class="d-hid text-danger mt-1 company_exist">Company Name Exist</div>
                              </div>
                        

                              <div class="d-hid">
                                <?php if(isset($company_names)){
                                    foreach($company_names as $company){
                                ?>
                                    <div class="company_names"><?php echo $company['company_name']?></div>
                                <?php }}?>
                              </div>
                            <div class="form-row">
                              <div class="form-group col-md-6">
                                <label for="customer_address">Representative Name</label>
                                <input value = "<?php echo $company_info['representative_name']?>" type="text" class="form-control" id="representative_name" placeholder="Representative Name" name = "representative_name">
                              </div>
                              <div class="form-group col-md-6">
                                <label >Representative Contact</label>
                                <input value = "<?php echo $company_info['representative_mobile']?>" type="number" class="form-control"  id = "representative_mobile" placeholder="Representative mobile" name = "representative_mobile">
                              </div>
                            </div>
                            
                            
                            <button type="submit" class="btn btn-success" name ="update" id = "company_update_btn">Update</button>
                          </form>
                    </div>
                </div>
               
               </div>
           </div>
        </div>
    </section>
    <div class="btn-block  py-2 footer bg-dark text-center text-light" style ="text-transform:uppercase; letter-spacing:3px; font-size:12px;position:absolute; bottom:0">&copy MD Rifat Sarker</div>

   <script src = "js/edit_company.js?<?php echo date('Y-m-d_H:i:s'); ?>"></script>
    <script src="js/all.js?v=<?php echo date('d-m-i') ?>"></script>
</body>
</html>