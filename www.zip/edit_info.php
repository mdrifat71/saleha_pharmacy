<?php
session_start();
include_once 'class/Session.php';
if(Session::check("login", "true")){
    $user_name= Session::get("username");
}else{
    header("location:login.php");
}
include 'class/Customer.php';
include 'class/Add_due.php';

$customer = new Customer;
$id = '';
if(isset($_GET['id']) and !empty($_GET['id'])){
    $id = $_GET['id'];

}else{
    header("location:index.php");
}

if(isset($_POST['update'])){
    $customer_name = $_POST['customer_name'];
    $customer_address = $_POST['customer_address'];
    $customer_mobile = $_POST['customer_mobile'];
    $customer_type = $_POST['customer_type'];

    if (!empty($customer_name) and !empty($customer_address) and !empty($customer_mobile) and !empty($customer_type)){
    
        
        if($customer->update($customer_name, $customer_address, $customer_mobile, $customer_type,$id)){
            header("location:customer_profile.php?id=$id");
            
        }else{
            $err = true;
        }
    }
}
$customer_info = $customer->selectById($id);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="icons/css/all.css">
    <link rel="stylesheet" href="css/style.css?<?php echo date('Y-m-d_H:i:s'); ?>">
</head>
<body class="bg-light">
    
    <!--header start-->
    <section id = "header" style="position:sticky; z-index:1000000;;top:0">
        <div class=" btn-block bg-warning text-center" style ="letter-spacing:3px">
            SALEHA PHARMACY
        </div>
        <div class="container">
           
                <ul>
                    <li class="">
                        <a href="index.php" >
                            <i class="fa fa-address-book  menu-icon"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="customer_list.php">
                            <i class="fa fa-users  menu-icon"></i>
                            <span>Customer List</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="add_customer.php">
                            <i class="fa fa-plus menu-icon"> <i class="fa fa-users"></i></i>
                            <span>Add customer</span>
                        </a>
                    </li>
                    <li class="a-menu">
                        <a href="add_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-briefcase  menu-icon"></i></i>
                            <span>Add due</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="pay_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-credit-card  menu-icon"></i></i>
                            <span>Pay due</span>
                        </a>
                    </li>
                    <li class="logout">
                        <a href="logout.php?logout">
                            <i class="fa fa-sign-out  menu-icon"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                    <li class="back">
                        <button class="btn " onclick="history.go(-1)"><i class=" fa fa-arrow-left"></i></button>
                    </li>
                    
                </ul>
            
        </div>
    </section>

    <!--header end-->

    <!--add due-->

    <section id="add-customer">
        <div class="container">
           <div class="row">
               <div class="col-lg-2"></div>
               <div class="col-lg-8 mb-4">
                <div class="card mt-5 bg-dark text-white">
                    <div class="card-header">
                        <h4>CUSTOMER DETAILS</h4>
                    </div>
                    <div class="card-body customer-form">
                        <form action="" method = "post">
                            <div class="form-group">
                                <label for="customer_name">Name</label>
                                <input value = "<?php echo $customer_info['customer_name']?>" type="text" class="form-control" id="customer_name" placeholder="Name" name ="customer_name">
                              </div>
                            <div class="form-row">
                              <div class="form-group col-md-6">
                                <label for="customer_address">Adress</label>
                                <input value = "<?php echo $customer_info['customer_address']?>" type="text" class="form-control" id="customer_address" placeholder="Adress" name = "customer_address">
                              </div>
                              <div class="form-group col-md-6">
                                <label >Contact</label>
                                <input value = "<?php echo $customer_info['customer_mobile']?>" type="number" class="form-control"  id = "customer_mobile" placeholder="Contact" name = "customer_mobile">
                              </div>
                            </div>
                            <div class="form-row">
                                
                                <div class="form-group col-md-6">
                                  <label for="">Type</label>
                                  <select  class="form-control" id ="select" name = "customer_type">
                                    <option value="2" <?php if($customer_info['customer_type'] == 2) echo "selected"?>>Customer</option>
                                    <option value="1" <?php if($customer_info['customer_type'] == 1) echo "selected"?> >Doctor</option>
                                  </select>
                                </div>
                                
                              </div>
                            
                            <button type="submit" class="btn btn-success" name ="update" id = "customer_update_btn">Update</button>
                          </form>
                    </div>
                </div>
               
               </div>
           </div>
        </div>
    </section>
    <div class="btn-block  py-2 footer bg-dark text-center text-light" style ="text-transform:uppercase; letter-spacing:3px; font-size:12px;position:absolute; bottom:0">&copy MD Rifat Sarker</div>

   <script src = "js/customer_update.js?<?php echo date('Y-m-d_H:i:s'); ?>"></script>
    <script src="js/main.js"></script>
    <script src="js/all.js?v=<?php echo date('d-m-i') ?>"></script>
</body>
</html>