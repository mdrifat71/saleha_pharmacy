<?php
session_start();
include_once 'class/Session.php';
if(Session::check("login", "true")){
    $user_name= Session::get("username");
}else{
    header("location:login.php");
}
include 'class/Customer.php';
include 'class/Add_due.php';
include_once 'class/Utility.php';
$customer = new Customer;
$add_due = new Add_due;


$customer_list = $customer->selectAll();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="icons/css/all.css">
    <link rel="stylesheet" href="css/style.css?<?php echo date('Y-m-d_H:i:s'); ?>">
</head>
<body class="bg-light">
    
    <!--header start-->
    <section id = "header" style="position:sticky; z-index:1000000;;top:0">
        <div class=" btn-block bg-warning text-center" style ="letter-spacing:3px">
            SALEHA PHARMACY
        </div>
        <div class="container">
           
                <ul>
                    <li class="">
                        <a href="index.php" >
                            <i class="fa fa-address-book  menu-icon"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="customer_list.php">
                            <i class="fa fa-users  menu-icon"></i>
                            <span>Customer List</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="add_customer.php">
                            <i class="fa fa-plus menu-icon"> <i class="fa fa-users"></i></i>
                            <span>Add customer</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="add_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-briefcase  menu-icon"></i></i>
                            <span>Add due</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="pay_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-credit-card  menu-icon"></i></i>
                            <span>Pay due</span>
                        </a>
                    </li>
                    <li class="logout">
                         <a href="logout.php?logout">
                            <i class="fa fa-sign-out  menu-icon"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                    <li class="back">
                        <button class="btn " onclick="history.go(-1)"><i class=" fa fa-arrow-left"></i></button>
                    </li>
                    
                </ul>
            
        </div>
    </section>

    <section id="main" class="mt-4">
        <div class="container">
            <div class="">
                <div class="menu_btn">
                    <span class="btn btn-sm btn-success menu " selected = "true" value = "1">Customer Payment</span>
                    <span class="btn btn-sm btn-primary menu" value = "2" >Customer Due </span>
                    <span class="btn btn-sm btn-primary menu" value = "3">Company Payment</span>
                    <span class="btn btn-sm btn-primary menu" value = "4">Company Due</span>
                    <span class="btn btn-sm btn-primary menu"  value = "5">Expense</span>
                    <span class="btn btn-sm btn-primary menu" value = "6">Sell</span>

                </div>
                
                
            </div>
            <hr>
            <div class="mt-3">
                <div class="form-group form-inline">
                    <label for="date" class="mr-1">Date</label>
                    <input type="number" class="form-control date_field form-control-sm mr-3" style = "width:60px">

                    <label for="month" class="mr-1">Month</label>
                    <select name="" id="" class="form-control form-control-sm month_field  mr-3 ">
                        <option value="0">Select Month</option>
                        <option value="1">January</option>
                        <option value="2">February</option>
                        <option value="3">March</option>
                        <option value="4">April</option>
                        <option value="5">May</option>
                        <option value="6">June</option>
                        <option value="7">July</option>
                        <option value="8">August</option>
                        <option value="9">September</option>
                        <option value="10">October</option>
                        <option value="11">November</option>
                        <option value="12">December</option>

                    </select>
                    <label for="year" class="mr-1">Year</label>
                    <input type="number" class="form-control form-control-sm year_field  mr-3"style = "width:80px" >
                    <button class="btn btn-success btn-sm" id = "show_btn">Show</button>
                </div>
            </div>
            <hr>
        </div>
    </section>
    
    <!---notification base
                        <div class="alert alert-danger d-flex text-muted due_history_item">
                            <p class="m-0">Due ৳67, <b><a href="customer_profile.php?id=">Rifat Sarker</a></b></p>
                            <span class="ml-auto">10 July, 20202 5:45</span>
                        </div>
    -->



    <section id="history_wraper " class="mb-5">
        <div class="container">
           
                <div class="tab">
                
                </div>
               
                <button class="btn btn-block btn-dark btn-sm rounded-0"></button>

                <div class="history mt-4">
                       
                </div>
            
        </div>
    </section>
    <!--header end-->

    <!--add due-->

    
    <div class="btn-block  py-2 footer bg-dark text-center text-light" style ="text-transform:uppercase; letter-spacing:3px; font-size:12px; position:absolute; bottom:0;">&copy MD Rifat Sarker</div>
    
    <script src="js/history.js?v=<?php echo date('d-m-i-s') ?>"></script>

</body>
</html>