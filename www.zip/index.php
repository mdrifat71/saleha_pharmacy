<?php
session_start();
include_once 'class/Session.php';
if(Session::check("login", "true")){
    $user_name= Session::get("username");
}else{
    header("location:login.php");
}
include 'class/Customer.php';
include 'class/Add_due.php';
include 'class/Pay_due.php';
include_once 'class/Company.php';
include_once 'class/Sell.php';
include_once 'class/Cost.php';
include_once 'class/Utility.php';
$customer = new Customer;
$add_due = new Add_due;
$pay_due = new Pay_due;
$company = new Company;
$sell = new Sell;
$cost = new Cost;
if(isset($_POST['upload'])){
   
    $name = $_FILES['file']['name'];
    $arr = explode(".",$name);
    $ext = end($arr);
    $tmp_name = $_FILES['file']['tmp_name'];
    $loc = "db/saleha_pharmacy.$ext";
    if($ext == 'db'){
        move_uploaded_file($tmp_name, $loc);
         
    }
}


if(isset($_POST['add_sell'])){
    $sell_ammount = $_POST['sell_ammount'];
    $sell_id = md5(uniqid());
    $sell_date = date('Y:m:d h:i:s');
    if($sell->setter($sell_id, $sell_ammount,$sell_date)){
        if($sell->insert()){
            Session::set('sell_inserted', 'true');
        }else{
            Session::set("sell_inserted", "false");
        }
    }
}



if(isset($_POST['add_cost'])){
     $cost_id = md5(uniqid());
     $cost_ammount = $_POST['cost_ammount'];
     $cost_description = $_POST['description'];
     $cost_date = date('Y:m:d h:i:s');

     if($cost->setter($cost_id,$cost_ammount, $cost_description, $cost_date)){
         if($cost->insert()){
             Session::set("cost_added", "true");
            
         }else{
             Session::set("cost_added", "false");
            echo "not added";
         }
     }
}



$total_customer = $customer->count();
$toatal_due = $customer->total_due();
$no_due_customer = $customer->no_due_customer();
$due_customer = $total_customer - $no_due_customer;


$payment_history = $pay_due->payment_history();
$due_history = $add_due->due_history();


$total_doctor = $customer->doctor_count();
$doctor_due = $customer->doctor_due();


$due_today = $add_due->due_today();

$due_this_month = $add_due->due_this_month();


$total_company = $company->count();
$company_due = $company->total_due();

$sell_today = $sell->sell_today();
$cost_today  = $cost->cost_today();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="icons/css/all.css">
    <link rel="stylesheet" href="css/style.css?<?php echo date('Y-m-d_H:i:s'); ?>">
</head>
<body class="bg-light">
    
    <!--header start-->
    
    <section id = "header" style="position:sticky; z-index:1000000;;top:0">
        <div class=" btn-block bg-warning text-center" style ="letter-spacing:3px">
            SALEHA PHARMACY
        </div>
        <div class="container">
           
                <ul>
                    <li class="a-menu">
                        <a href="index.php" >
                            <i class="fa fa-address-book  menu-icon"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="customer_list.php">
                            <i class="fa fa-users  menu-icon"></i>
                            <span>Customer List</span>
                        </a>
                    </li>
                    <li>
                        <a href="add_customer.php">
                            <i class="fa fa-plus menu-icon"> <i class="fa fa-users"></i></i>
                            <span>Add customer</span>
                        </a>
                    </li>
                    <li>
                        <a href="add_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-briefcase  menu-icon"></i></i>
                            <span>Add due</span>
                        </a>
                    </li>
                    <li>
                        <a href="pay_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-credit-card  menu-icon"></i></i>
                            <span>Pay due</span>
                        </a>
                    </li>
                    <li class="logout">
                        <a href="logout.php?logout">    
                            <i class="fa fa-sign-out  menu-icon"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                    <li class="back">
                        <button class="btn " onclick="history.go(-1)"><i class=" fa fa-arrow-left"></i></button>
                    </li>
                    
                </ul>
            
        </div>
    </section>

    <!--header end-->

    
    <!--main start-->
    <section id="main">
        <div class="container">
            <div class="row mt-5">
                <div class="col-md-12 col-lg-6">
                 <div class="row">
                    <div class=" col-md-6">
                        <div class="card ">
                            <div class="card-header text-center bg-success text-light"><h6 class="text-uppercase font-weight-bold"> Total Customer</h6></div>

                            <div class="card-body  bg-dark text-light text-center ">
                                
                                <h2 class=""><?php echo $total_customer; ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class=" col-md-6">
                        <div class="card ">
                            <div class="card-header text-center bg-danger text-light">
                                <h6 class="text-uppercase font-weight-bold"> Total DUE</h6>
                            </div>

                            <div class="card-body bg-dark text-light text-center">
                                
                                <h2 class=""> <span>৳ </span> <?php echo $toatal_due?></h2>
                            </div>
                        </div>
                    </div>
                 </div>
                </div>
               
                <div class="col-md-12 col-lg-6">
                    <div class="row">
                        <div class="  col-md-6">
                            <div class="card ">
                                <div class="card-header text-center bg-success text-light">
                                    <h6 class="text-uppercase font-weight-bold"> No Due Customer</h6>
                                </div>
                                <div class="card-body  bg-dark text-light text-center ">
                                    
                                        
                                        <h2 class=""><?php echo $no_due_customer; ?></h2>
                                    
                                </div>
                            </div>
                        </div>
                        <div class=" col-md-6">
                            <div class="card ">
                                <div class="card-header text-center bg-danger text-light">
                                    <h6 class="text-uppercase font-weight-bold"> Due Customer</h6>
                                </div>
                                <div class="card-body  bg-dark text-light text-center">
                                        <h2 class=""><?php echo $due_customer?></h2>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-3 mb-5">
                <div class=" col-md-6 col-lg-3">
                    <div class="card ">
                        <div class="card-header text-center bg-info text-light">
                            <h6 class="text-uppercase font-weight-bold"> Total Doctor </h6>
                        </div>
                        <div class="card-body  bg-dark text-light text-center">
                                <h2 class=""><?php echo $total_doctor?></h2>
                        </div>
                    </div>
                 </div>

                 <div class=" col-md-6 col-lg-3">
                    <div class="card ">
                        <div class="card-header text-center bg-danger text-light">
                            <h6 class="text-uppercase font-weight-bold"> Doctor Due </h6>

                        </div>
                        <div class="card-body  bg-dark text-light text-center">
                                <h2 class=""><span>৳ </span><?php echo $doctor_due?></h2>
                            
                        </div>
                    </div>
                 </div>

                 <div class=" col-md-6 col-lg-3">
                    <div class="card ">
                        <div class="card-header text-center bg-danger text-light">
                            <h6 class="text-uppercase font-weight-bold">  Due Today</h6>
                        </div>
                        <div class="card-body  bg-dark text-light text-center">
                           
                                
                                <h2 class=""><span>৳ </span><?php echo $due_today?></h2>
                            
                        </div>
                    </div>
                 </div>

                 <div class=" col-md-6 col-lg-3">
                    <div class="card ">
                        <div class="card-header text-center bg-danger text-light">
                            <h6 class="text-uppercase font-weight-bold">  Due This Month</h6>
                        </div>
                        <div class="card-body  bg-dark text-light text-center">
                                <h2 class=""><span>৳ </span><?php echo $due_this_month?></h2>
                            
                        </div>
                    </div>
                 </div>
                 
            </div>
        </div>

        <hr>
        <div class="container mt-2">
            <div class="alert alert-success <?php  if(!Session::check("sell_inserted", "true")) echo "d-hid"; Session::set("sell_inserted","2");?>">New Sell inserted</div>
            <div class="alert alert-success <?php if(!Session::check("cost_added", "true")) echo "d-hid"; Session::set("cost_added",2);?>">New Cost inserted</div>
           
        </div>
        <div class="container">
            <div class="row">
                <a class="btn-success btn ml-3 btn-sm" href= "company_list.php"><i class="fa fa-building"></i>    Company List</a>
                <button href="" class="btn btn-danger ml-3 btn-sm add_cost"> Add Expense</button>
                <button href="" class="btn btn-success ml-3 btn-sm add_sell"><i class="fa fa-shopping-cart"></i> Add Sell</button>
                <a href="history.php" class="btn btn-info ml-3 btn-sm"><i class="fa fa-history"></i> History</a>
                <a href="history.php" class="btn btn-info ml-3 btn-sm"><i class="fa fa-line-chart"></i> Statistics</a>
            </div>
        </div>

        <hr>

        <div class="container">
            <div class="row">
                <div class=" col-md-6 col-lg-3">
                    <div class="card ">
                        <div class="card-header text-center bg-warning text-dark">
                            <h6 class="text-uppercase font-weight-bold"> Total Company</h6>
                        </div>
                        <div class="card-body  bg-dark text-light text-center">
                                <h2 class=""><span>৳ </span><?php echo $total_company?></h2>
                            
                        </div>
                    </div>
                 </div>
                 <div class=" col-md-6 col-lg-3">
                    <div class="card ">
                        <div class="card-header text-center bg-warning text-dark"> 
                            <h6 class="text-uppercase font-weight-bold"> Company Due</h6>
                        </div>
                        <div class="card-body  bg-dark text-light text-center">
                           
                                <h2 class=""><span>৳ </span><?php echo $company_due?></h2>
                            
                        </div>
                    </div>
                 </div>

                 <div class=" col-md-6 col-lg-3">
                    <div class="card ">
                        <div class="card-header text-center bg-success text-dark"> 
                            <h6 class="text-uppercase font-weight-bold"> Sell Today</h6>
                        </div>
                        <div class="card-body  bg-dark text-light text-center">
                           
                                <h2 class=""><span>৳ </span><?php echo $sell_today?></h2>
                            
                        </div>
                    </div>
                 </div>

                 <div class=" col-md-6 col-lg-3">
                    <div class="card ">
                        <div class="card-header text-center bg-danger text-light"> 
                            <h6 class="text-uppercase font-weight-bold"> Expense Today</h6>
                        </div>
                        <div class="card-body  bg-dark text-light text-center">
                           
                                <h2 class=""><span>৳ </span><?php echo $cost_today?></h2>
                            
                        </div>
                    </div>
                 </div>

            </div>

        </div>
        <hr>
    <!--export import-->
        <div class="container d-flex">
            <div>
                <a class="btn btn-success btn-sm mb-2" href="db/saleha_pharmacy.db"><i class="fa fa-download"></i> Export Database</a>
            </div>
            <div>
                <form action="" style= "width:200px" enctype="multipart/form-data" method="post">
                    <div class=" mb-3 input-group ml-2" >
                    <input type="file" class="form-control"  name="file" style="font-size:12px" >
                    <div class="input-group-prepend">
                        <button class="btn btn-info btn-sm "  name ="upload" type="submit"><i class="fa fa-upload" ></i> </button>
                    </div>
                </form>
            </div>
        </div>
        </div>
        <hr class="line mt-0">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12">
                    <div class="mb-3">
                        <span class=" btn alert-success btn-sm ">Payment History</span>
                        <input type="number" style = "width:30%; font-size:12px" class="form-control d-inline mt-1 payment_history_count" value = "5" title = "history count" placeholder = "history count">
                    </div>
                    <hr>
                    <div class="activity">
                    <?php 
                        if(!empty($payment_history)){
                            foreach($payment_history as $item){
                    ?>
                        <div class="alert alert-success d-flex text-muted payment_history_item">
                            <p class="m-0">pay  ৳<?php echo $item['payment_ammount']?>, <b><a href="customer_profile.php?id=<?php echo $item['customer_id'] ?>"><?php  echo $item['customer_name'] ?></a></b></p>
                            <span class="ml-auto"><?php echo  Utility::date($item['payment_date'])?></span>
                        </div>
                    <?php
                            }
                        }
                    ?>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12">
                    <div class="mb-3">
                        <span class="btn alert-danger btn-sm ">Due History</span>
                        <input type="number" style = "width:30%; font-size:12px" class="form-control d-inline mt-1 due_history_count" value = "5" title = "history count" placeholder = "history count">
                    </div>
                    <hr>
                    <div class="activity">
                        <?php
                            if(!empty($due_history)){
                                foreach($due_history as $item){
                        ?>
                        <div class="alert alert-danger d-flex text-muted due_history_item">
                            <p class="m-0">new due ৳<?php echo $item['due']?>, <b><a href="customer_profile.php?id=<?php echo $item['customer_id']?>"><?php echo $item['customer_name']?></a></b></p>
                            <span class="ml-auto"><?php echo  Utility::date($item['due_date'])?></span>
                        </div>

                        <?php
                                }
                            }
                        ?>
                    </div>
                </div>

            </div>
        </div>
    </section>


    <!--modal-->
    <div id="modal" class="d-hid modal_1" style="height:500px;">
            <div class="modal-container">
                <div class="card payment-modal">
                    <div class="card-header bg-danger text-center text-light font-weight-normal">
                       Add Expense
                    </div>

                    <div class="card-body bg-dark text-light">
                        <form action="" method = "post" >
                            
                            <div class="form-group">
                                <label for="">Expanse Ammount</label>
                                <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">৳</span>
                                </div>
                                <input type="number" name = "cost_ammount" class="form-control cost_ammount" placeholder="Cost">
                                
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="">Description</label>
                                <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">D</span>
                                </div>
                               <textarea name="description" id="" cols="15" rows="3" class="form-control description" placeholder="Description"></textarea>
                                
                                </div>
                            </div>
                            
                            <button class="mt-3 btn btn-success add_cost_btn btn-sm" name= "add_cost"  >ADD</button>
                            <button class="mt-3 btn btn-danger cancel_btn btn-sm">Cancel</button>
                        </form>
                    </div>
                </div> 
            </div>
    </div>

    <div id="modal" class="d-hid modal_2" style="height:500px;">
            <div class="modal-container">
                <div class="card payment-modal">
                    <div class="card-header bg-success text-center text-light font-weight-normal">
                        Sell Ammount
                    </div>

                    <div class="card-body">
                        <form action="" method = "post" >
                            
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">৳</span>
                                </div>
                                <input type="number" name = "sell_ammount" class="form-control sell_ammount">
                               
                            </div>
                            <button class="mt-3 btn btn-success add_sell_btn btn-sm" name= "add_sell"  >ADD</button>
                            <button class="mt-3 btn btn-danger cancel_btn btn-sm">Cancel</button>
                        </form>
                    </div>
                </div> 
            </div>
    </div>


    <div class="btn-block  py-2 footer bg-dark text-center text-light mt-3" style ="text-transform:uppercase; letter-spacing:3px; font-size:12px;">&copy MD Rifat Sarker</div>
    
    <!--main end-->
    <script src="js/main.js?<?php echo date('d-m-y-i') ?>"></script>
    <script src="js/all.js?v=<?php echo date('d-m-i') ?>"></script>
</body>
</html>