

let company_add_btn = document.querySelector(".company_add_btn");




/*modal*/
let modal = document.getElementById("modal");
//when a button is pressed modal will be shown
function modal_activity(modal){
    let body = document.querySelector("body");
    let h  =window.scrollY;

    modal.setAttribute("style","top:"+h+"px")
    modal.classList.remove('d-hid')
    body.style.position = "relative";
    body.style.height = "100vh";
    body.style.overflow = "hidden";

    let cancel_button = document.querySelectorAll(".cancel_btn");
    cancel_button.forEach(item =>{
        item.addEventListener("click", e =>{
            e.preventDefault();
            modal.classList.add('d-hid')
            let body = document.querySelector("body");
            body.style.height = "";
            body.style.overflow = "";
        })
    })
    
    
}


let modal_1 = document.querySelector(".modal_1");
company_add_btn.addEventListener("click", e =>{
   modal_activity(modal_1);
  
})



/*company field validation*/
let add_company = document.getElementById("add_company");

let company_name = document.getElementById("company_name");
let representative_name = document.getElementById("representative_name");
let representative_mobile = document.getElementById("representative_mobile");
let  isExist = false;
company_name.addEventListener("keyup", (e)=>{
    let company_exist = document.querySelector(".company_exist");
    if(company_name.value == "" || representative_name.value == "" || representative_mobile.value == ""){
        add_company.setAttribute("disabled", "true");
        company_exist.classList.add('d-hid');
    }else{
        add_company.removeAttribute("disabled");
    }

        /*company existence validation*/
        
        let all_company_name = document.querySelectorAll(".all_company_name");
        let l = all_company_name.length;
        for(let i = 0; i < l; i++){
            let item = all_company_name[i];
            let type_value = company_name.value.toLowerCase().trim();
            item = item.innerText.toLowerCase();
            if(item == type_value){
                add_company.setAttribute("disabled", "true");
                company_exist.classList.remove('d-hid');
                isExist = true;
                break;
            }else{
                company_exist.classList.add('d-hid');
                isExist = false;
            }
        
        }

})

representative_name.addEventListener("keyup", (e)=>{
    if(company_name.value == "" || representative_mobile.value == "" || representative_mobile.value == "" || isExist == true){
        add_company.setAttribute("disabled", "true");
    }else{
        add_company.removeAttribute("disabled");
    }
})

representative_mobile.addEventListener("keyup", (e)=>{
    if(company_name.value == "" || representative_mobile.value == "" || representative_mobile.value == "" || isExist ==true){
        add_company.setAttribute("disabled", "true");
    }else{
        add_company.removeAttribute("disabled");
    }
})




/*cancel_button.addEventListener("click", e =>{
     company_name.value = "" ;
     representative_mobile.value = "" ;
      representative_mobile.value = "";
})*/

/*company delete*/

let company_del_btn = document.querySelectorAll(".company_del_btn");
let modal_2 = document.querySelector(".modal_2");

company_del_btn.forEach(item=>{
    item.addEventListener("click", e =>{
        modal_activity(modal_2);

        let customer_id_field = document.querySelector(".company_id_field");
        let delete_company = document.querySelector(".delete_company");
        let parent = item.parentElement.parentElement;
        delete_company.innerHTML = '<i class="fa fa-user mr-2"></i>'+item.parentElement.parentElement.childNodes[3].innerText;
        let customer_id  = item.getAttribute("customer_id");
        customer_id_field.setAttribute ("value",customer_id);
    });
})


/*search company*/

let search = document.getElementById("search_company");
let company_info = document.querySelectorAll(".company_info")
let no_data = document.querySelector(".no-data")

search.addEventListener("keyup", (e)=>{
    let count = 0;
    let search_value = search.value.toLowerCase();
    company_info.forEach(item =>{
        
        let company_name = item.childNodes[3].innerText.toLowerCase();
        let representative_name = item.childNodes[5].innerText.toLowerCase();
        
        search_Parent = company_name + representative_name;
        let result = search_Parent.search(search_value);


        if(result <=0 && search_value != ""){
            item.classList.add("d-hid");
        }else{
            item.classList.remove("d-hid");
            count++;
        }

        
        
       
    });

    if(count <= 0 && search_value != ""){
        no_data.classList.remove("d-hid");
    }else{
        no_data.classList.add("d-hid");
    }

})
