

/*modal*/

let modal = document.getElementById("modal");
//when a button is pressed modal will be shown
function modal_activity(modal){
    let body = document.querySelector("body");
    let h  =window.scrollY;

    modal.setAttribute("style","top:"+h+"px")
    modal.classList.remove('d-hid')
    body.style.position = "relative";
    body.style.height = "100vh";
    body.style.overflow = "hidden";

    let cancel_button = document.querySelectorAll(".cancel_btn");
    cancel_button.forEach(item =>{
        item.addEventListener("click", e =>{
            e.preventDefault();
            modal.classList.add('d-hid')
            let body = document.querySelector("body");
            body.style.height = "";
            body.style.overflow = "";
        })
    })
    
    
}

let modal_1 = document.querySelector(".modal_1");
let pay_modal_btn = document.querySelector(".pay_modal_btn");

pay_modal_btn.addEventListener("click", e =>{
    modal_activity(modal_1);
})

let modal_2 = document.querySelector(".modal_2");
let due_modal_btn = document.querySelector(".due_modal_btn");

due_modal_btn.addEventListener("click", e=>{
    modal_activity(modal_2);
})

let company_payment = document.querySelector(".company_payment");
let pay_btn = document.querySelector(".pay_btn");
let company_due = document.querySelector(".company_due").innerText;


function payment_field_action(company_payment){
   
    if(company_payment == "" || parseInt(company_payment) > parseInt(company_due)){
        pay_btn.setAttribute("disabled", "true");
    }else{
        pay_btn.removeAttribute("disabled");
    }
}
company_payment.addEventListener("keyup", e=>{
    
   payment_field_action(company_payment.value);
})

company_payment.addEventListener("paste",e =>{
    let company_payment_value = e.clipboardData.getData('Text');
    payment_field_action(company_payment_value);
    
    
})


/*history*/

let payment_history_count = document.querySelector(".payment_history_count");
let due_history_count = document.querySelector(".due_history_count");
let clear_due_history_btn = document.querySelectorAll(".clear_due_history_btn");

let clear_payment_history_btn = document.querySelectorAll(".clear_payment_history_btn");

let clear_all_payment = document.querySelector(".clear_all_payment_history")
let clear_all_due = document.querySelector(".clear_all_due_history");

let no_due = document.querySelector(".no_due");
let no_payment = document.querySelector(".no_payment")

let company_id = document.querySelector(".company_id").innerText;
let payment_history_item = document.querySelectorAll(".payment_history_item")
let due_history_item = document.querySelectorAll(".due_history_item")


/*ajax*/

const ajax = (method, source, data)=>{
    let xhr = new XMLHttpRequest;
    
    xhr.open(method,source);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(data);
    return xhr;
}


let p_deleted_count = 0;
clear_payment_history_btn.forEach(item =>{
    item.addEventListener("click", (e)=>{
        e.preventDefault();
        let payment_id = item.getAttribute("payment_id");
        if(confirm("do you want to clear"))
        {
            let method = "POST";
            let source = "ajax/company_payment.php";
            let data = "payment_id="+payment_id+"&action=clear_payment";
            let ajx = ajax(method, source, data);
            
            ajx.onreadystatechange = function(){
                if(this.readyState == 4 && this.status == 200){
                    if(this.responseText == 1){
                        p_deleted_count++;
                        item.parentElement.classList.add("d-hid")          
                        if(clear_payment_history_btn.length - p_deleted_count < 1){
                            clear_all_payment.classList.add("d-hid")
                            no_payment.classList.remove("d-hid")
                        }
                    }
                }
            }
        }
    })
})


function history_count_run(x,arr){
    if(x >= arr.length)
        x = arr.length;

    for(let i = 0; i < x; i++){
        arr[i].classList.remove('d-hid')
       
    }
    for(let i = x; i < arr.length; i++){
        arr[i].classList.add('d-hid');
    }
}

let d_deleted_count = 0;
clear_due_history_btn.forEach(item =>{
    item.addEventListener("click", (e)=>{
        e.preventDefault();
        let due_id = item.getAttribute("due_id");
        if(confirm("do you want to clear"))
        {
            let method = "POST";
            let source = "ajax/company_due.php";
            let data = "due_id="+due_id+"&action=clear_due";
            let ajx = ajax(method, source, data);

            ajx.onreadystatechange = function(){
                
                if(this.readyState == 4 && this.status == 200){
                    if(this.responseText == 1){
                        item.parentElement.classList.add("d-hid")
                        clear_payment_history_btn = document.querySelectorAll(".clear_payment_history_btn");
                        d_deleted_count++;
                        
                        if(clear_due_history_btn.length-d_deleted_count < 1){
                                clear_all_due.classList.add("d-hid");
                                no_due.classList.remove("d-hid")
                        }
                    }
                }
            }
        }
    })
})


clear_all_payment.addEventListener("click", (e) =>{
    if(confirm("do you want to delete?")){
        let method = "POST";
        let source = "ajax/company_payment.php";
        let data = "company_id="+company_id+"&action=clear_all_payment";
        let ajx = ajax(method, source, data);
       
        ajx.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){

                if(this.responseText == 1){
                    clear_all_payment.classList.add("d-hid")
                    no_payment.classList.remove("d-hid")
                    payment_history_item.forEach(item =>{
                        item.classList.add("d-hid")
                    })
                }
               
            }
        }
    }
})

clear_all_due.addEventListener("click", (e) =>{
    if(confirm("do you want to delete?")){
        let method = "POST";
        let source = "ajax/company_due.php";
        let data = "company_id="+company_id+"&action=clear_all_due";
        let ajx = ajax(method, source, data);
      
        ajx.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){

                if(this.responseText == 1){
                    clear_all_due.classList.add("d-hid")
                    no_due.classList.remove("d-hid")
                    due_history_item.forEach(item =>{
                        item.classList.add("d-hid")
                    })
                }
                
            }
        }
    }
})





payment_history_count.addEventListener("keyup", e=>{
    let n = parseInt(payment_history_count.value);
    history_count_run(n,payment_history_item)
    
})


due_history_count.addEventListener("keyup", e=>{
    let m = parseInt(due_history_count.value)
    history_count_run(m,due_history_item)
})
let m = parseInt(due_history_count.value)
let n = parseInt(payment_history_count.value);


history_count_run(m,due_history_item)
history_count_run(n,payment_history_item)