let s = document.getElementById("select");//customer_type


let adding_btn = document.getElementById("customer_add_btn");
let input_list = document.querySelectorAll(".customer-form input");
let adding_result = 0 ;
const xhr = new XMLHttpRequest();




const variable_init = ()=>{
    let customer_name = document.getElementById('customer_name');
    let customer_address = document.getElementById('customer_address');
    let customer_mobile = document.getElementById('customer_mobile');
    let customer_due = document.getElementById('customer_contact');
    
}



const customer_adding_action = ()=>{
    variable_init();

    let customer_adding_history = document.querySelector(".customer_adding_history");
    customer_adding_history.classList.remove('d-hid');
    let adding_notification = document.getElementById('adding_notification_body');

    /*notification*/
    let div = document.createElement('div');
    let link = "customer_profile.php?id="+adding_result ;
    let a = document.createElement('a');
    a.setAttribute("href",link);
    a.text = customer_name.value;
    div.className = "alert alert-success font-sm";

    let text = document.createTextNode(" added successfully");
    div.appendChild(a);
    div.appendChild(text);
    adding_notification_body.prepend(div);
}

const validation = ()=>{
    variable_init();
    if(customer_name.value =='' ||
    customer_address.value == ''||
    customer_mobile.value == ''){
        return false;
       
    }else{
        return true;
    }
}


adding_btn.addEventListener("click", e => {
    e.preventDefault();
    variable_init();
    console.log(s.value)
    /*ajax*/
    xhr.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
            adding_result = this.responseText;
            console.log(adding_result)
            
            if(validation()){
                adding_btn.classList.add("btn-info");
                adding_btn.classList.remove("btn-success");
                if(adding_result == 0){
                    console.log("not added");
                }else{
                    customer_adding_action();
                    customer_name.value ='';
                    customer_address.value = '';
                    customer_mobile.value = '';
                    customer_due.value = '';
                   // console.log(adding_result)
                }
                
            }
    }
    
    };
    xhr.open('POST','ajax/add_customer.php');
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("customer_name="+customer_name.value+"&customer_address="+customer_address.value+"&customer_mobile="+customer_mobile.value+"&customer_due="+customer_due.value+"&customer_type="+s.value);

    
    
    
})


input_list.forEach(item => {
    item.addEventListener("keyup", (e)=>{
        if(validation()){
            adding_btn.classList.add("btn-success");
            adding_btn.classList.remove("btn-danger")
            adding_btn.classList.remove("btn-info")
            adding_btn.classList.remove("disabled")
        }else{
            adding_btn.classList.add("btn-danger")
            adding_btn.classList.add("disabled")
            adding_btn.classList.remove("btn-success")
        }
    })
})



