let search = document.getElementById("search_customer");

let customer_info = document.querySelectorAll(".customer_info");

let no_customer = document.querySelector(".no-data")

let customer_sort = document.querySelector(".customer_sort");
let doctor_sort = document.querySelector(".doctor_sort");
let no_due_sort = document.querySelector(".no_due_sort");
let due_sort = document.querySelector(".due_sort");
let all_sort = document.querySelector(".all_sort");

let sort_btns = document.querySelectorAll(".sort_btn");

let customer_del_btn = document.querySelectorAll('.customer_del_btn');

function btn_color_change(target){
    sort_btns.forEach(item =>{
       if(item == target){
            item.classList.add("btn-danger");
            item.classList.remove("btn-primary");
       }else{
            item.classList.remove("btn-danger");
            item.classList.add("btn-primary");
       }
    })
}


search.addEventListener("keyup", (e)=>{
    let count = 0;
    let search_value = search.value.toLowerCase();
    customer_info.forEach(item =>{
        
        let customer_name = item.childNodes[3].innerText.toLowerCase();
        let customer_mobile = item.childNodes[7].innerText.toLowerCase();
        
        search_Parent = customer_name+customer_mobile;
        let result = search_Parent.search(search_value);


        if(result <=0 && search_value != ""){
            item.classList.add("d-hid");
        }else{
            item.classList.remove("d-hid");
            count++;
        }

        
        console.log(count)
       
    });

    if(count <= 0 && search_value != ""){
        no_customer.classList.remove("d-hid");
    }else{
        no_customer.classList.add("d-hid");
    }

})

customer_sort.addEventListener("click", (e)=>{
    
    btn_color_change(e.target)
     //customer_delete message
     let msg_btn_r = document.querySelector(".msg_btn_r");
     let msg_btn_w =document.querySelector(".msg_btn_w");
     msg_btn_r.classList.add("d-hid");
     msg_btn_w.classList.add("d-hid")

    let sl = 1;
    customer_info.forEach(item =>{
        if(item.getAttribute("type") == "doctor"){
            item.classList.add("p-hid");
           
        }else{
            item.classList.remove("p-hid");
            item.childNodes[1].innerText = sl;
            sl++;
        }
    })
})

doctor_sort.addEventListener("click", (e)=>{
    let sl = 1;
    btn_color_change(e.target)
     //customer_delete message
     let msg_btn_r = document.querySelector(".msg_btn_r");
     let msg_btn_w =document.querySelector(".msg_btn_w");
     msg_btn_r.classList.add("d-hid");
     msg_btn_w.classList.add("d-hid")

    customer_info.forEach(item =>{
        if(item.getAttribute("type") == "customer"){
            item.classList.add("p-hid");
        }else{
            item.classList.remove("p-hid");
            item.childNodes[1].innerText = sl;
            sl++;
        }
    })
})
no_due_sort.addEventListener("click", (e)=>{
    btn_color_change(e.target)
     //customer_delete message
     let msg_btn_r = document.querySelector(".msg_btn_r");
     let msg_btn_w =document.querySelector(".msg_btn_w");
     msg_btn_r.classList.add("d-hid");
     msg_btn_w.classList.add("d-hid")
    let sl = 1;
    customer_info.forEach(item =>{
        if(item.childNodes[9].innerText == 0){
            item.classList.remove('p-hid');
            item.childNodes[1].innerText = sl;
            sl++;
        }else{
            item.classList.add('p-hid');
            
        }
    })
})


due_sort.addEventListener("click", (e)=>{
    btn_color_change(e.target)
    //customer_delete message
    let msg_btn_r = document.querySelector(".msg_btn_r");
    let msg_btn_w =document.querySelector(".msg_btn_w");
    msg_btn_r.classList.add("d-hid");
    msg_btn_w.classList.add("d-hid")

    let sl = 1;
    customer_info.forEach(item =>{
        if(item.childNodes[9].innerText != 0){
            item.classList.remove('p-hid');
            item.childNodes[1].innerText = sl;
            sl++;
        }else{
            item.classList.add('p-hid');
        }
    })

})

all_sort.addEventListener("click", (e)=>{
    //customer_delete message
    let msg_btn_r = document.querySelector(".msg_btn_r");
    let msg_btn_w =document.querySelector(".msg_btn_w");
    msg_btn_r.classList.add("d-hid");
    msg_btn_w.classList.add("d-hid")
    btn_color_change(e.target)
    let sl = 1;
    customer_info.forEach(item =>{
        item.classList.remove('p-hid');
        item.childNodes[1].innerText = sl;
        sl++;
    })

})


let customer_id ;
let pay_modal_btn = document.querySelector(".pay_modal_btn");

let modal = document.getElementById("modal");
let cancel_button = document.querySelector(".cancel_btn");
let delte_user = document.querySelector(".delete_user");



customer_del_btn.forEach(item =>{
    item.addEventListener("click", e =>{
        
        e.preventDefault();
        let customer_id_field = document.querySelector(".customer_id_field");
       
        customer_id  = item.getAttribute("customer_id");
        customer_id_field.setAttribute ("value",customer_id);
      
        
        let parent = item.parentElement.parentElement;
        delte_user.innerHTML = '<i class="fa fa-user mr-2"></i>'+item.parentElement.parentElement.childNodes[3].innerText;
        
        /*modal */
        let body = document.querySelector("body");
        let h  =window.scrollY;

        modal.setAttribute("style","top:"+h+"px")
        modal.classList.remove('d-hid')
        body.style.position = "relative";
        body.style.height = "100vh";
        body.style.overflow = "hidden";
        /*===*/
    })
})




cancel_button.addEventListener("click", e =>{
    e.preventDefault();
    modal.classList.add('d-hid')
    let body = document.querySelector("body");
    body.style.height = "";
    body.style.overflow = "";
})


