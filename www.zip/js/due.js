let customer_name = document.getElementById('customer_name');
let customer_suggestion_list = document.querySelectorAll('.customer_suggestion ul li.sug_list');
let customer_suggestion = document.querySelector('.customer_suggestion');
let  customer_id ;
let no_customer = document.querySelector('.no_customer')
let customer_due = document.getElementById('customer_due')
let remove_button = document.querySelector('.remove_button');
let due_history = document.querySelector('.due_history');

let due_id;
let due_del_btn ;
let is_customer_selected = false;
let is_customer_name_validated = false;
let is_customer_due_validated = false;

let add_due_button = document.getElementById("add_due_button")
const xhr = new XMLHttpRequest();

//arrow variable
let sug_list_vis = document.querySelectorAll(".customer_suggestion ul li.sug_list:not(.d-hid)");
let position = -1;
let hide_sc = document.querySelector(".hide_sc")
/*utility*/
const var_init = () =>{
    let  customer_id = document.getElementById('customer_id');
    let customer_due = document.getElementById('customer_due')
}
const time_date =() =>{
    let d = new Date;
    let month_list = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November","December"];
    return d.getDate()+" "+month_list[d.getMonth()]+","+d.getFullYear();
}




/*main*/

customer_name.addEventListener('keyup', (e) =>{
    let search_value = customer_name.value.toLowerCase();
    let count = 0;
   
    
       
 
    customer_suggestion_list.forEach(item =>{
        customer_suggestion.classList.remove('d-hid')
        
        
        let text = item.childNodes[1].innerText.toLowerCase()+item.childNodes[2].innerText;
        
        let r = text.search(search_value);
        
        if (search_value.trim() == ""){
            item.classList.remove('d-hid');
            count++;
            r = 0;
        }
        if(r >= 0){
            item.classList.remove('d-hid');
            count++;
        }else{
            item.classList.add('d-hid')
        }

        item.addEventListener("click", (e)=>{
            customer_name.value = item.childNodes[1].innerText;
            
            customer_suggestion.classList.add('d-hid')
            customer_id = item.childNodes[3].innerText;
            customer_name.setAttribute('disabled','true');
            remove_button.classList.remove('d-hid');
            


            //btn 
            is_customer_selected = true;
            is_customer_name_validated = true;
            customer_name.style.border = "2px solid green";

            if(customer_due.value == "" || is_customer_selected == false){
                add_due_button.classList.remove('btn-info')
                add_due_button.classList.remove('btn-success')
                add_due_button.classList.add('btn-danger')
                add_due_button.classList.add('disabled')
                
            }
            else{
                add_due_button.classList.remove('btn-info')
                add_due_button.classList.remove('btn-danger')
                add_due_button.classList.add('btn-success')
                add_due_button.classList.remove('disabled')
              
                customer_name.style.border = "2px solid green";
            }
            
        })


        if(count ==0 && search_value != ''){
            no_customer.classList.remove('d-hid');
        }else{
            no_customer.classList.add('d-hid');
        }
    })


    //for arrow key functionlity
    if(e.keyCode != 40 && e.keyCode != 38){
        sug_list_vis = document.querySelectorAll(".customer_suggestion ul li.sug_list:not(.d-hid)");
        position = -1;
       
        let selected = document.querySelector(".selected");
        if(selected != null){
            selected.classList.remove("selected");
        } 
    }
})

remove_button.addEventListener('click', (e)=>{
    customer_name.removeAttribute("disabled");
    customer_name.value = '';
    remove_button.classList.add('d-hid')
    add_due_button.classList.add('btn-danger')
    add_due_button.classList.add('disabled');
    is_customer_selected = false;
    customer_name.style.border = "2px solid red";
})


/*validation*/
customer_name.addEventListener("keyup", (e)=>{
    if(is_customer_selected == false){
        add_due_button.classList.remove('btn-info')
        add_due_button.classList.remove('btn-success')
        add_due_button.classList.add('btn-danger')
        add_due_button.classList.add('disabled')
        is_customer_name_validated = false;
        
    }
})

customer_due.addEventListener("keyup", (e)=>{

    var_init();
    
    if(customer_due.value == "" || is_customer_selected == false){
        customer_suggestion.classList.add('d-hid')
        add_due_button.classList.remove('btn-info')
        add_due_button.classList.remove('btn-success')
        add_due_button.classList.add('btn-danger')
        add_due_button.classList.add('disabled')
        is_customer_due_validated = false;
    }
    else{
        add_due_button.classList.remove('btn-info')
        add_due_button.classList.remove('btn-danger')
        add_due_button.classList.add('btn-success')
        add_due_button.classList.remove('disabled')
        is_customer_due_validated = true;
    }
})


add_due_button.addEventListener("click", e =>{
    e.preventDefault();
    customer_name.style.border = "0";
    
    if(is_customer_name_validated == true && is_customer_due_validated == true){
         /*ajax*/
        xhr.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                
                if(this.responseText != 0){
                     due_id = this.responseText;
                    console.log(due_id)
                    


                    /*some action*/
                    let tr = document.createElement('tr');
                    let name_td = document.createElement('td');
                    let due_td = document.createElement('td');
                    let date_td = document.createElement('td');
                    let a = document.createElement('a');
                    let btn = document.createElement('button');
                    btn.classList.add("btn");
                    btn.classList.add('btn-danger');
                    btn.classList.add('btn-sm')
                    btn.classList.add('due_del_btn');
                    btn.setAttribute('del_id', due_id);
                    btn.setAttribute('listener', false);
                    btn.setAttribute('customer_id', customer_id)

                    btn.innerText = "Delete";
                    let action_td = document.createElement('td');
                    action_td.prepend(btn);

                    a.setAttribute("href", "customer_profile.php?id="+customer_id);
                    a.text = customer_name.value;
                    
                    name_td.appendChild(a);
                    due_td.innerText = customer_due.value+" ৳";
                    date_td.innerText = time_date();

                    tr.appendChild(name_td);
                    tr.appendChild(due_td);
                    tr.appendChild(date_td)
                    tr.appendChild(action_td)

                    due_history.prepend(tr);

                    due_del_btn = document.querySelectorAll('.due_del_btn');
                    deletion();
                    /*changes*/
                    customer_name.value = "";
                    customer_due.value = "";
                    add_due_button.classList.add('btn-info')
                    add_due_button.classList.remove('btn-danger')
                    add_due_button.classList.remove('btn-success')
                    customer_name.removeAttribute("disabled");
                    remove_button.classList.add('d-hid')

                    is_customer_selected = false;
                    is_customer_name_validated = false;
                    is_customer_due_validated = false;

                 
                }
            }
            
        };
       
        xhr.open('POST','ajax/add_due.php');
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.send("customer_id="+customer_id+"&customer_due="+customer_due.value+"&action=add");

        

    }
})


   //deletion

    function deletion(){
        if(due_del_btn != null){
            due_del_btn.forEach(item =>{


                if(item.getAttribute('listener') == "false"){
                    item.setAttribute("listener", "true");
                    item.addEventListener("click", (e)=>{
                        e.preventDefault();
                        console.log(e.target)
                        if(confirm("Do you want to delete?")){
                            let id = item.getAttribute("del_id");
                            let customer_id = item.getAttribute('customer_id')
                            let due = parseInt(item.parentElement.parentElement.childNodes[1].innerText);
                            console.log(due);
             
                            /*ajax for deletion*/
                            let xhr = new XMLHttpRequest;
                            xhr.onreadystatechange = function(){
                                if(this.readyState == 4 && this.status ==200){
                                    
                                    if(this.responseText == 1){
                                        e.target.parentElement.parentElement.classList.add('d-hid')
                                       
                                    }
                                }
                            }
                            xhr.open('POST','ajax/add_due.php');
                            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                            xhr.send("due_id="+due_id+"&action=delete&"+"due="+due+"&customer_id="+customer_id);
                        }
                    })
                }
            })
        }
    }


/*pay due*/





document.addEventListener("keydown", e=>{
    if(!customer_suggestion.classList.contains(".d-hid")){
        //down arrow
        let max = sug_list_vis.length;
        if(e.keyCode == 40 && position != max){
            position++;
            if(position == max){
                position = 0;
                
            }
            if(position != 0){
                sug_list_vis[position - 1].classList.remove("selected")
            }else{
                sug_list_vis[max-1].classList.remove("selected")
            }

            
                hide_sc.scrollTop =43*position;
            console.log(hide_sc.scrollTop)
            sug_list_vis[position].classList.add("selected");
        }

//up arrow
        if(e.keyCode == 38 && position >= 0){
            position--;
            if(position == -1){
                position = max - 1;
              //  hide_sc.scrollTop = 42 * max;
            }
            if(position !=max -1){
                sug_list_vis[position + 1].classList.remove("selected");
            }else{
                sug_list_vis[0].classList.remove("selected");
            }

           
                hide_sc.scrollTop = hide_sc.scrollTop - 43*position;
                console.log(hide_sc.scrollTop)
            sug_list_vis[position].classList.add("selected");
            sug_list_vis[position].classList.add("selected");   
        }
    }


    if(e.keyCode == 13){
            let selected = document.querySelector(".selected");
            if(selected != null){
                customer_name.value = selected.childNodes[1].innerText;
            
                customer_suggestion.classList.add('d-hid')
                customer_id = selected.childNodes[3].innerText;
                customer_name.setAttribute('disabled','true');
                remove_button.classList.remove('d-hid');
                is_customer_selected = true;
                is_customer_name_validated = true;
                customer_name.style.border = "2px solid green";
            }
            
    }
})

