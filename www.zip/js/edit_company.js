let company_name = document.getElementById("company_name");
let company_names = document.querySelectorAll(".company_names");
let company_update_btn = document.getElementById("company_update_btn");
let company_exist = document.querySelector(".company_exist")
let representative_name = document.getElementById("representative_name");
let representative_mobile = document.getElementById("representative_mobile")
let previous_name = company_name.value;


company_name.addEventListener("keyup", e =>{
    let name = company_name.value;
    company_name_action(name);
    if(company_name.value == "" || representative_name.value == "" || representative_mobile.value == ""){
        
        company_update_btn.setAttribute("disabled", "true");
    }else{
        
        company_update_btn.removeAttribute("disabled");
    }
})

representative_name.addEventListener("keyup", e =>{
    if(company_name.value == "" || representative_name.value == "" || representative_mobile.value == ""){
       
        company_update_btn.setAttribute("disabled", "true");
    }else{
       
        company_update_btn.removeAttribute("disabled");
    }
})

representative_mobile.addEventListener("keyup", e =>{
    if(company_name.value == "" || representative_name.value == "" || representative_mobile.value == ""){
        
        company_update_btn.setAttribute("disabled", "true");
    }else{
        
        company_update_btn.removeAttribute("disabled");
    }
})
function company_name_action(name){
   let length = company_names.length;
    for (let i = 0; i < length ; i++){
        let item = company_names[i];
        if(item.innerText.toLowerCase().trim() == name.toLowerCase().trim() && name.toLowerCase().trim() != previous_name.toLowerCase().trim()){
            company_exist.classList.remove('d-hid');
            company_update_btn.setAttribute("disabled", "true");
            break;
        }else{
            company_exist.classList.add('d-hid');
            company_update_btn.removeAttribute("disabled");
        }
    } 
}

