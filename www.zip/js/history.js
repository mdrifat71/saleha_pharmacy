document.addEventListener("DOMContentLoaded", function(){
    let menu = document.querySelectorAll(".menu");
    let selected_option = document.querySelector("[selected]") //select the menu which has attribute selected
    
   
    //show buton for history
    let show_btn = document.getElementById("show_btn");
    
    //history container
    let history = document.querySelector(".history");
    let tab = document.querySelector('.tab');

    //date field variable 
    
    let date_field = document.querySelector(".date_field");
    let month_field = document.querySelector(".month_field");
    let year_field = document.querySelector(".year_field");

    //dell button
    let del_btn = document.querySelectorAll('.del_btn');

    //date more & default
    
    let d = new Date();
  
    date_field.setAttribute("value", d.getDate()) 
    
    year_field.value = d.getFullYear();
    let tmp_date =(parseInt(d.getMonth())+1)*2 +1;
    month_field.childNodes[tmp_date].setAttribute("selected", "");
 
    //ajax
    
    const ajax = (method, source, data)=>{
        let xhr = new XMLHttpRequest;
        
        xhr.open(method,source);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.send(data);
        return xhr;
    }
    
    //delete action
    const del_action = function(item){
        let id = item.getAttribute("id");
        let method = "POST";
        let source;
        let data;
        switch (parseInt(selected_option.getAttribute("value"))){
            case 1:
                source = "ajax/pay_due.php";
                data = "payment_id="+id+"&action=clear_payment";
                break;
            case 2:
                source = "ajax/add_due.php";
                data = "due_id="+id+"&action=clear_due";
                break;
            case 3:
                source = "ajax/company_payment.php";
                data = "payment_id="+id+"&action=clear_payment";
                break;
            case 4:
                source = "ajax/company_due.php";
                data = "due_id="+id+"&action=clear_due";
                break;
            case 5:
                source = "ajax/cost.php";
                data = "cost_id="+id+"&action=clear_cost";
                break;
            case 6:
                source = "ajax/sell.php";
                data = "sell_id="+id+"&action=clear_sell";
                break;
           
        }

      
        if(confirm("Are you sure")){
            let ajx = ajax(method, source, data);

            ajx.onreadystatechange  = function(){
                if(this.readyState == 4 && this.status == 200){
                    if(this.responseText == 1){
                        
                        let target = document.getElementById(id).parentElement;
                        target.remove();
                    }
                    console.log(this.responseText)
                }
            }
        }
}

///del listener

const del_event = ()=>{
    del_btn =document.querySelectorAll(".del_btn");
    if(del_btn != null){
        del_btn.forEach(item =>{
            item.addEventListener("click", function(){
                del_action(this)
            })
            
        })
    }
}


    
    //menu click action
    
    function menu_click(e){
        
        menu.forEach(item =>{
           if(e.target == item){
               item.classList.add("btn-success");
               item.classList.remove("btn-primary");
               item.setAttribute("selected", "true")
           }else{
                item.classList.remove("btn-success");
                item.classList.add("btn-primary");
                item.removeAttribute("selected")
           }
          
           
           
        })

        selected_option = document.querySelector("[selected]") //update every click to menu
        tab_action(selected_option);
        show();
        del_event();
        
       
    }

    //tab show or hide 
    function tab_action(selected_option){
        switch(parseInt(selected_option.getAttribute('value'))){
            case 1:
                msg  = ' <div class="btn btn-success btn-block alert">Customer Payment History</div>';
                tab.innerHTML = msg;
                break;
            case 2:
                msg = ' <div class="btn btn-danger btn-block alert">Customer Due History</div>';
                tab.innerHTML = msg;
                break;
            case 3:
                msg = ' <div class="btn btn-success btn-block alert">Company Payment History</div>';
                tab.innerHTML = msg;
                break;
            case 4:
                msg = ' <div class="btn btn-danger btn-block alert">Customer Due History</div>';
                tab.innerHTML = msg;
                break;
            case 5:
                msg = ' <div class="btn btn-danger btn-block alert">Expanse History</div>';
                tab.innerHTML = msg;
                break;
            case 6:
                msg = ' <div class="btn btn-success btn-block alert">Sell History</div>';
                tab.innerHTML = msg;
                break;
        }
    }
    
    //validation
    const date_validation = date =>{
       
        if(date != NaN){
            if( date <=31){
                return true;
            }
            return false;
        }
       return false;
       
    }
    
    const month_validation = month =>{
        if(month != ""){
            if(month > -1 && month <13){
                return true;
            }
            return false;
        }
        return false;
    }
    
    const year_validation = year =>{
        if(year != ""){
            if(year / 1000 > 0){
                return true;
            }
            return false;
        }
        return false;
    }
    
    //show_btn_action
    const show = () =>{
        let is_date_ok = date_validation(date_field.value);
        let is_month_ok = month_validation(month_field.value);
        let is_year_ok = year_validation(year_field.value)
        let msg;
        

        if (is_date_ok && is_month_ok && is_year_ok){
            
            //if everythig is fine send ajax request
            let method = "POST";
            let source = "ajax/history.php";
            let data = "date="+date_field.value+"&month="+month_field.value+"&year="+year_field.value+"&selected="+selected_option.getAttribute("value");

            let ajx = ajax(method, source, data);

            ajx.onreadystatechange = function(){
                if(this.readyState == 4 && this.status == 200){
                    if(this.responseText == 0){
                        let no_history = '<p class ="alert alert-dark"> No History Found !!</p>';

                        history.innerHTML = no_history;
                    }else{
                        history.innerHTML =this.responseText;
                        del_event();
                    }
                   
                   
                }
            
            }
        }else{
            console.log("problem")
        }
      
    }
    
    
    //=======event Listener===========//
    
    
    //when user click the upper menu
    menu.forEach(item =>{
        item.addEventListener("click", (e)=>{
            menu_click(e);
        });
    })
    
    //when user click show button to show targer history
    
    show_btn.addEventListener("click", e =>{
        show();
    })

    //dell btn
   

    //default call
    show();
    tab_action(selected_option);
   
})

