/*customer adding*/


let payment_history_count = document.querySelector(".payment_history_count");
let due_history_count = document.querySelector(".due_history_count");
let due_history_item = document.querySelectorAll(".due_history_item");
let payment_history_item = document.querySelectorAll(".payment_history_item");

console.log(payment_history_count)

function history_count_run(x,arr){
    if(x >= arr.length)
        x = arr.length;

    for(let i = 0; i < x; i++){
        arr[i].classList.remove('d-hid')
       
    }
    for(let i = x; i < arr.length; i++){
        arr[i].classList.add('d-hid');
    }
}

payment_history_count.addEventListener("keyup", e=>{
    let n = parseInt(payment_history_count.value);
    history_count_run(n,payment_history_item)
    
})


due_history_count.addEventListener("keyup", e=>{
    let m = parseInt(due_history_count.value)
    history_count_run(m,due_history_item)
})
let m = parseInt(due_history_count.value)
let n = parseInt(payment_history_count.value);


history_count_run(m,due_history_item)
history_count_run(n,payment_history_item)


/*modal*/

let add_cost = document.querySelector(".add_cost");
let add_sell = document.querySelector(".add_sell");

let modal = document.getElementById("modal");
//when a button is pressed modal will be shown
function modal_activity(modal){
    let body = document.querySelector("body");
    let h  =window.scrollY;

    modal.setAttribute("style","top:"+h+"px")
    modal.classList.remove('d-hid')
    body.style.position = "relative";
    body.style.height = "100vh";
    body.style.overflow = "hidden";

    let cancel_button = document.querySelectorAll(".cancel_btn");
    cancel_button.forEach(item =>{
        item.addEventListener("click", e =>{
            e.preventDefault();
            modal.classList.add('d-hid')
            let body = document.querySelector("body");
            body.style.height = "";
            body.style.overflow = "";
        })
    })
    
    
}


let modal_1 = document.querySelector(".modal_1");
let modal_2 = document.querySelector(".modal_2");

add_cost.addEventListener("click", e =>{
   modal_activity(modal_1);
  
})

add_sell.addEventListener("click", e=>{
    modal_activity(modal_2)
})

