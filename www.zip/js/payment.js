
let customer_name = document.getElementById('customer_name');
let customer_suggestion_list = document.querySelectorAll('.customer_suggestion ul li.sug_list');
let customer_suggestion = document.querySelector('.customer_suggestion');
let  customer_id ;
let no_customer = document.querySelector('.no_customer')

let remove_button = document.querySelector('.remove_button');
let payment_history = document.querySelector('.payment_history');

let sug;
let is_customer_selected = false;
let is_customer_name_validated = false;
let is_customer_due_validated = false;

let pay_due_button = document.getElementById("pay_due_button");
let customer_payment = document.getElementById("customer_payment")

let due;
let selected_customer;

let pay_overflow = document.querySelector(".pay_overflow");

//arrow variable
let sug_list_vis = document.querySelectorAll(".customer_suggestion ul li.sug_list:not(.d-hid)");
let position = -1;
let hide_sc = document.querySelector(".hide_sc"); //suggestion container div
/*utility*/

const time_date =() =>{
    let d = new Date;
    let month_list = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November","December"];
    return d.getDate()+" "+month_list[d.getMonth()]+","+d.getFullYear();
}

/*ajax*/

    const ajax = (method, source, data)=>{
    let xhr = new XMLHttpRequest;
    
    xhr.open(method,source);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(data);
    return xhr;
}


/*main*/

customer_name.addEventListener('keyup', (e) =>{
    let search_value = customer_name.value.toLowerCase();
    let count = 0;
    customer_suggestion.removeAttribute("d-hid")
    customer_suggestion_list.forEach(item =>{
        customer_suggestion.classList.remove('d-hid')
        let text = item.childNodes[1].innerText.toLowerCase()+item.childNodes[2].innerText;
        
        
        let r = text.search(search_value);
        if(item.getAttribute("no_due") != "true"){

            if (search_value.trim() == ""){
                item.classList.remove('d-hid');
                count++;
                r = 0;
            }
            if(r >= 0 ){
                item.classList.remove('d-hid');
                count++;
            }else{
                item.classList.add('d-hid')
            }
        }

        
        item.addEventListener("click", (e)=>{
            selected_customer = item;
            customer_name.value = item.childNodes[1].innerText;
            due = item.getAttribute("due");
            customer_suggestion.classList.add('d-hid')
            customer_id = item.childNodes[3].innerText;
            customer_name.setAttribute('disabled','true');
            remove_button.classList.remove('d-hid');
            


            //btn 
            is_customer_selected = true;
            is_customer_name_validated = true;

            customer_name.style.border = "2px solid green";

            if(customer_payment.value == "" || is_customer_selected == false){
                pay_due_button.classList.remove('btn-info')
                pay_due_button.classList.remove('btn-success')
                pay_due_button.classList.add('btn-danger')
                pay_due_button.classList.add('disabled')
                
            }
            else{
                pay_due_button.classList.remove('btn-info')
                pay_due_button.classList.remove('btn-danger')
                pay_due_button.classList.add('btn-success')
                pay_due_button.classList.remove('disabled')
                
                customer_name.style.border = "2px solid green";
            }
            
        })
        


        if(count ==0 && search_value != ''){
            no_customer.classList.remove('d-hid');
        }else{
            no_customer.classList.add('d-hid');
        }

         //for arrow key functionlity
    if(e.keyCode != 40 && e.keyCode != 38){
        sug_list_vis = document.querySelectorAll(".customer_suggestion ul li.sug_list:not(.d-hid)");
        position = -1;
        let selected = document.querySelector(".selected");
        if(selected != null){
            selected.classList.remove("selected");
        } 
    }
    })
})

remove_button.addEventListener('click', (e)=>{
    customer_name.removeAttribute("disabled");
    customer_name.value = '';
    remove_button.classList.add('d-hid')
    pay_due_button.classList.add('btn-danger')
    pay_due_button.classList.add('disabled');
    is_customer_selected = false;
    customer_name.style.border = "2px solid red";
})


function customer_payment_action(payment_value){
    if(is_customer_selected == true && customer_payment.value != "" && payment_value != NaN && parseInt(due) >= parseInt(payment_value)){
        pay_due_button.classList.remove('btn-info')
        pay_due_button.classList.remove('btn-danger')
        pay_due_button.classList.add('btn-success')
        pay_due_button.classList.remove('disabled')
        pay_due_button.removeAttribute("disabled")
        
    }else{
        pay_due_button.classList.remove('btn-info')
        pay_due_button.classList.remove('btn-success')
        pay_due_button.classList.add('btn-danger')
        pay_due_button.classList.add('disabled')
        pay_due_button.setAttribute("disabled","true")
        
    }

    if(parseInt(due) < parseInt(customer_payment.value)){
        pay_overflow.classList.remove("d-hid");
        pay_overflow.innerText = "Customer due is "+due;
        
    }else{
        pay_overflow.classList.add("d-hid");
    }
}

customer_payment.addEventListener("keyup", (e)=>{
   let payment_value = customer_payment.value;
   customer_payment_action(payment_value)
})

customer_payment.addEventListener("paste", e =>{
    let payment_value = e.clipboardData.getData('Text');
    customer_payment_action(payment_value);
})
pay_due_button.addEventListener("click", (e)=>{
    e.preventDefault();
    
    let method = "POST";
    let source = "ajax/pay_due.php";
    let data = "customer_id="+customer_id+"&customer_payment="+customer_payment.value+"&action=add_payment";
    let xhr = ajax(method, source, data);
    xhr.onreadystatechange = function(){
        if(this.readyState == 4 && this.status ==200){

           if(this.responseText != 0){
               
                let payment_id = this.responseText;

                /*ajax for existing due*/
                let ajx = ajax("POST","ajax/pay_due.php","action=check_due&customer_id="+customer_id)
                ajx.onreadystatechange = function(){
                    if(this.readyState == 4 && this.status == 200){
                        if (this.responseText == 0 ){

                            //if customer has no due
                            selected_customer.setAttribute("no_due", "true");
                            selected_customer.classList.add('d-hid')
                            
                        }
                    }
                }


               /*history*/
                let tr = document.createElement('tr');
                let name_td = document.createElement('td');
                let payment_td = document.createElement('td');
                let date_td = document.createElement('td');
                let a = document.createElement('a');
                let btn = document.createElement('button');
                btn.classList.add("btn");
                btn.classList.add('btn-danger');
                btn.classList.add('btn-sm')
                btn.classList.add('pay_del_btn');
                btn.setAttribute('payment_id', payment_id);
                btn.setAttribute('listener', false);
                btn.setAttribute('customer_id', customer_id)

                btn.innerText = "Delete";
                let action_td = document.createElement('td');
                action_td.prepend(btn);

                a.setAttribute("href", "customer_profile.php?id="+customer_id);
                a.text = customer_name.value;
                
                name_td.appendChild(a);
                payment_td.innerText = customer_payment.value+" ৳";
                date_td.innerText = time_date();

                tr.appendChild(name_td);
                tr.appendChild(payment_td);
                tr.appendChild(date_td)
                tr.appendChild(action_td)

                payment_history.prepend(tr);



                /*del button*/
                let pay_del_btn = document.querySelectorAll('.pay_del_btn')
                let c_p_value = customer_payment.value;
                pay_del_btn.forEach((item) => {
                    if(item.getAttribute("listener") == "false"){
                       item.setAttribute("listener", "true")
                        item.addEventListener("click", (e)=>{
                            if(confirm("Do you want to delete?")){
                                let method = "POST";
                                let source = "ajax/pay_due.php";
                                let data = "customer_id="+customer_id+"&customer_payment="+c_p_value+"&payment_id="+payment_id+"&action=delete_payment";
                                
                                let ajx = ajax(method, source,data);
                                ajx.onreadystatechange = function (){
                                    if(this.readyState == 4 && this.status == 200){
                                        item.parentElement.parentElement.classList.add('d-hid')
                                        console.log(this.responseText)
                                    
                                    
                                    }
                                }
                            }
                        })
                    }
                })

                /*reinit*/
                customer_name.value = "";
                customer_payment.value = "";
                pay_due_button.classList.remove("btn-success");
                pay_due_button.classList.add("btn-info")
                customer_name.removeAttribute("disabled");
                remove_button.classList.add('d-hid')
                customer_name.style.border = "0";
                is_customer_selected = false;
           }
        }
    }
    
})



// arrow functionality

document.addEventListener("keydown", e=>{
    if(!customer_suggestion.classList.contains(".d-hid")){
        //down arrow
        let max = sug_list_vis.length;
        if(e.keyCode == 40 && position != max){
            position++;
            if(position == max){
                position = 0;
                
            }
            if(position != 0){
                sug_list_vis[position - 1].classList.remove("selected")
               
            }else{
                sug_list_vis[max-1].classList.remove("selected")
            }
            sug_list_vis[position].classList.add("selected");

            
        }

//up arrow
        if(e.keyCode == 38 && position >= 0){
            position--;
            if(position == -1){
                position = max - 1;
            }
            if(position !=max -1){
                sug_list_vis[position + 1].classList.remove("selected");
            }else{
                sug_list_vis[0].classList.remove("selected");
            }

            sug_list_vis[position].classList.add("selected");   
        }
    }


    if(e.keyCode == 13){
            let selected = document.querySelector(".selected");
            if(selected != null){
                customer_name.value = selected.childNodes[1].innerText;
            
                customer_suggestion.classList.add('d-hid')
                customer_id = selected.childNodes[3].innerText;
                customer_name.setAttribute('disabled','true');
                remove_button.classList.remove('d-hid');
                is_customer_selected = true;
                is_customer_name_validated = true;
                customer_name.style.border = "2px solid green";
                due = selected.getAttribute("due");
                selected_customer = selected;
            }
            
    }
})

