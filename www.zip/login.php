<?php 
session_start();
include_once 'class/Session.php';
if(Session::check("login", "true")){
    header("location:index.php");
}


include_once 'class/Admin.php';

$admin = new Admin;

if(isset($_POST['register'])){
	$admin_username = $_POST['admin_username'];
	$admin_password= $_POST['admin_password'];
	$admin_full_name = $_POST['admin_full_name'];
	$security_question = $_POST['security_question'];
	$security_question_answer = $_POST['security_question_answer'];

	$admin->insert($admin_username, $admin_password, $admin_full_name, $security_question, $security_question_answer);
	
	
}

$match =false;
if(isset($_POST['login'])){
	$admin_username = $_POST['admin_username'];
	$admin_password= $_POST['admin_password'];
	$match = $admin->match($admin_username, $admin_password);
	if($match){
		Session::check("match","true");
		Session::set("login", "true");
		Session::set("username", $admin_username);
		Session::set("password", $admin_password);
		header("location:index.php");
	}else{
		Session::set("match", "false");
	}
}

$admin_count = $admin->select();

if($admin_count == 0){
	$register =true;
}else{
	$register = false;
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>The Entrar-shadow Website form | w3layouts</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link href="css/login.css" rel='stylesheet' type='text/css' />
		
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		<!--webfonts-->
		
		<!--//webfonts-->
</head>
<body>
	 <!-----start-main---->
	 <div class="main">


		<?php if($register == false){?>
			<div class="login-form">
			<h1>Admin Login</h1>
					<div class="head">
						<img src="images/user.png" alt=""/>
					</div>
				<form method = "post">
						<div class="mb-2 text-danger"><?php if(Session::check("match","false")) echo "User name or Password is incorrect!"?></div>
						<input  name = "admin_username" type="text" class="text" value="USERNAME" onfocus="this.value = '';" >
						<input name ="admin_password" type="password" value="Password" onfocus="this.value = '';" >
						<div class="submit">
							<input type="submit" onclick="myFunction()" value="LOGIN" name = "login">
					</div>	
					<p><a href="#">Forgot Password ?</a></p>
				</form>
			</div>
		<?php } else {?>

			<div class="login-form">
			<h1>Admin Registration</h1>
					<div class="head">
						<img src="images/user.png" alt=""/>
					</div>
				<form autocomplete="off" method="post">
						<input  name = "admin_username" type="text" class="text" placeholder="USERNAME" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'USERNAME';}" >
						<input name ="admin_full_name" type="text" placeholder="Full Name"  >
						<input name ="security_question" type="text" placeholder="Security Question">
						<input name ="security_question_answer" type="text" placeholder="Security Question Answer"  >
						<input name ="admin_password" type="password" placeholder="Password" >
						<div class="submit">
							<input type="submit" onclick="myFunction()" value="Register" name = "register">
					</div>	
					<p><a href="#">Forgot Password ?</a></p>
				</form>
			</div>
		<?php } ?>
			
		</div>
			 <!-----//end-main---->
		 	<script src="js/all.js?v=<?php echo date('d-m-i') ?>"></script>
</body>
</html>