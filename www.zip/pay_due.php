<?php
session_start();
include_once 'class/Session.php';
if(Session::check("login", "true")){
    $user_name= Session::get("username");
}else{
    header("location:login.php");
}
include 'class/Customer.php';
include 'class/Add_due.php';

$customer = new Customer;
$add_due = new Add_due;


$customer_list = $customer->selectAll();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="icons/css/all.css">
    <link rel="stylesheet" href="css/style.css?<?php echo date('Y-m-d_H:i:s'); ?>">
</head>
<body class="bg-light">
    
    <!--header start-->
    <section id = "header" style="position:sticky; z-index:1000000;;top:0">
        <div class=" btn-block bg-warning text-center" style ="letter-spacing:3px">
            SALEHA PHARMACY
        </div>
        <div class="container">
           
                <ul>
                    <li class="">
                        <a href="index.php" >
                            <i class="fa fa-address-book  menu-icon"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="customer_list.php">
                            <i class="fa fa-users  menu-icon"></i>
                            <span>Customer List</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="add_customer.php">
                            <i class="fa fa-plus menu-icon"> <i class="fa fa-users"></i></i>
                            <span>Add customer</span>
                        </a>
                    </li>
                    <li >
                        <a href="add_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-briefcase  menu-icon"></i></i>
                            <span>Add due</span>
                        </a>
                    </li>
                    <li class="a-menu">
                        <a href="pay_due.php">
                            <i class="fa fa-plus">   <i class="fa fa-credit-card  menu-icon"></i></i>
                            <span>Pay due</span>
                        </a>
                    </li>
                    <li class="logout">
                        <a href="logout.php?logout">
                            <i class="fa fa-sign-out  menu-icon"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                    <li class="back">
                        <button class="btn " onclick="history.go(-1)"><i class=" fa fa-arrow-left"></i></button>
                    </li>
                    
                </ul>
            
        </div>
    </section>

    <!--header end-->

    <!--add due-->

    <section id="add-customer">
        <div class="container">
           <div class="row">
              
               <div class="col-lg-6">
                <div class="card mt-5 bg-dark text-white">
                    <div class="card-header bg-success">
                        <h4>PAY DUE</h4>
                    </div>
                    <div class="card-body">
                        <form autocomplete="off">
                            <div class="form-group suggestion_parent">
                                <label for="customer_name">Name</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fa fa-user"></i></span>
                                    </div>
                                    <input type="text" class="form-control font-weight-bold" id="customer_name" placeholder="Name" >
                                </div>
                                
                                <p class="remove_button btn d-hid" title ="remove selection"><i class="fa fa-times"></i></p>
                                <div class="customer_suggestion d-hid ">
                                    <div class="hide_sc">
                                        <ul>
                                            <?php 
                                                if(!empty($customer_list)){
                                                    foreach($customer_list as $customer){
                                            ?>
                                                <li class="d-hid sug_list " <?php if($customer['customer_due'] == 0) echo "no_due = true"; ?> due="<?php  echo $customer['customer_due']; ?>"><i class = "<?php if($customer['customer_type'] == 1) echo "fa fa-user-md"; else echo "fa fa-wheelchair";?>"></i><span><?php echo $customer['customer_name'] ?></span><span class="contact"> <i class="fa fa-phone"></i><?php echo $customer['customer_mobile'] ?></span><span class="d-hid"><?php echo $customer['customer_id']?></span></li>
                                            <?php }}?>
                                            <li class="d-hid no_customer">No customer found</li>
                                        </ul>
                                    </div>
                                </div>
                              </div>
                            <div class="form-row">
                              <div class="form-group col-md-12">
                                <label for="">Ammount</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">৳</i></span>
                                    </div>
                                    <input type="number" class="form-control" id="customer_payment" placeholder="Due">
                                    
                                  </div>    
                                
                                
                              </div>
                              <div class=" alert-danger d-hid pay_overflow p-1 px-5  mb-3 rounded"></div>
                            </div>
                            <input type="hidden" id ="customer_id"  >
                            <button type="submit" class="btn btn-info" id ="pay_due_button">Pay</button>
                          </form>
                    </div>
                </div>
               
               </div>

            <!--Due History-->
               <div class="col-lg-6 mt-5">
               <section id="payment_history">
                    <div class="container">
                        <div class="row">
                            
                            <div class="col-12 p-0">
                                <div class="alert alert-success">
                                   Payment history
                                </div>
                                <table class="table mt-2 table-striped">
                                    <thead class="thead-dark">
                                    
                                    </thead>
                                    <tbody class="payment_history font-weight-bold">            
                                    
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                </section>
               </div>
           </div>
        </div>
    </section>


    <div class="btn-block  py-2 footer bg-dark text-center text-light" style ="text-transform:uppercase; letter-spacing:3px; font-size:12px;position:absolute; bottom:0">&copy MD Rifat Sarker</div>
    
    


    
    <script src= "js/payment.js?<?php echo date('d-m-y-h-m-s')?>"></script>
    
</body>
</html>